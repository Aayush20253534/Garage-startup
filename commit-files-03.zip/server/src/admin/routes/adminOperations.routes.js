const express = require("express");

const controller = require("../controllers/adminOperations.controller");
const { protect } = require("../../middlewares/auth.middleware");
const { authorizeRoles } = require("../../middlewares/role.middleware");
const validate = require("../../middlewares/validate.middleware");
const {
  bookingQuerySchema,
  clearBookingsSchema,
  customerQuerySchema,
  sendUserEmailSchema,
  sendNotificationSchema,
  userEmailSearchSchema,
} = require("../validations/adminOperations.validation");

const router = express.Router();

router.use(protect);
router.use(authorizeRoles("ADMIN", "INTERN"));

router.get("/stats", controller.getDashboardStats);
router.get(
  "/customers",
  customerQuerySchema,
  validate,
  controller.listCustomers,
);
router.get("/bookings", bookingQuerySchema, validate, controller.listBookings);
router.delete(
  "/bookings/all",
  authorizeRoles("ADMIN"),
  clearBookingsSchema,
  validate,
  controller.clearAllBookings,
);
router.get(
  "/email-users",
  userEmailSearchSchema,
  validate,
  controller.searchEmailUsers,
);
router.post(
  "/emails",
  sendUserEmailSchema,
  validate,
  controller.sendUserEmail,
);
router.post(
  "/notifications",
  sendNotificationSchema,
  validate,
  controller.sendNotification,
);

module.exports = router;
