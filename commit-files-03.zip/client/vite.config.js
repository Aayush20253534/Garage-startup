import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "path";

export default defineConfig({
  plugins: [react(), tailwindcss()],

  define: {
    __APP_BUILD_ID__: JSON.stringify(
      process.env.VERCEL_GIT_COMMIT_SHA ||
        process.env.VERCEL_DEPLOYMENT_ID ||
        `local-${Date.now()}`,
    ),
  },

  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },

  build: {
    sourcemap: false,
    manifest: true,
  },

  server: {
    host: "127.0.0.1",
    port: 8080,
    strictPort: true,
  },

  preview: {
    host: "127.0.0.1",
    port: 8080,
    strictPort: true,
  },
});
