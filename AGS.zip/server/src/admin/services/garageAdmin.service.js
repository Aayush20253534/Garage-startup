const prisma = require("../../config/prisma");
const ApiError = require("../../utils/apiError");
const { deleteCache, deletePattern } = require("../../utils/cache");
const garageOperationalService = require("./garageOperational.service");
const { deleteGaragesDeep } = require("./garageDeletion.service");

const garageListInclude = {
  owner: {
    select: {
      id: true,
      name: true,
      email: true,
      phone: true,
      role: true,
    },
  },
  wallet: true,
  services: {
    include: {
      service: {
        include: {
          category: true,
        },
      },
    },
    orderBy: { createdAt: "desc" },
  },
  images: {
    orderBy: [{ isThumbnail: "desc" }, { order: "asc" }],
  },
};

const garageDetailInclude = {
  ...garageListInclude,
  reviews: {
    include: {
      user: {
        select: {
          id: true,
          name: true,
          email: true,
          phone: true,
        },
      },
      booking: {
        select: {
          id: true,
          bookingCode: true,
          customerAcceptedAt: true,
          createdAt: true,
          vehicle: {
            select: {
              brand: true,
              model: true,
              registrationNumber: true,
            },
          },
          services: {
            include: {
              service: {
                select: {
                  id: true,
                  name: true,
                },
              },
            },
          },
          inspectionImages: {
            orderBy: [{ phase: "asc" }, { mediaType: "asc" }, { order: "asc" }],
          },
        },
      },
    },
    orderBy: { createdAt: "desc" },
  },
};

const parseBoolean = (value, fallback = true) => {
  if (value === undefined || value === null || value === "") return fallback;
  if (typeof value === "boolean") return value;
  return String(value).toLowerCase() === "true";
};

const normalizeScope = (value, fallback = "ALL") => {
  const text = String(value || "").trim();
  if (!text) return fallback;

  const reservedScope = text.toUpperCase();
  return reservedScope === "ALL" ? reservedScope : text;
};

const normalizeVehicleScope = (brandValue, modelValue) => {
  const vehicleBrand = normalizeScope(brandValue);

  if (vehicleBrand === "ALL") {
    return { vehicleBrand, vehicleModel: "ALL" };
  }

  return {
    vehicleBrand,
    vehicleModel: normalizeScope(modelValue),
  };
};

const listGarages = async (query = {}) => {
  const where = {
    ...(query.search && {
      OR: [
        { name: { contains: query.search, mode: "insensitive" } },
        { city: { contains: query.search, mode: "insensitive" } },
        { area: { contains: query.search, mode: "insensitive" } },
        { email: { contains: query.search, mode: "insensitive" } },
        { phone: { contains: query.search, mode: "insensitive" } },
      ],
    }),
    ...(query.isActive !== undefined && { isActive: query.isActive === "true" }),
    ...(query.isVerified !== undefined && { isVerified: query.isVerified === "true" }),
    ...(query.city && { city: { contains: query.city, mode: "insensitive" } }),
  };

  return prisma.garage.findMany({
    where,
    include: garageListInclude,
    orderBy: { createdAt: "desc" },
  });
};

const getGarage = async (garageId) => {
  const garage = await prisma.garage.findUnique({
    where: { id: garageId },
    include: garageDetailInclude,
  });

  if (!garage) throw new ApiError(404, "Garage not found");
  return garage;
};

const invalidateGarageAdminChanges = async (garageId) => Promise.allSettled([
  deleteCache(`garages:${garageId}:services`),
  deleteCache(`garages:detail:${garageId}`),
  deleteCache("public:stats:v2"),
  deletePattern("garages:list:*"),
  deletePattern("garages:public:*"),
]);

const updateGarageDetails = async (garageId, payload = {}) => {
  const existingGarage = await getGarage(garageId);
  const allowed = ["name", "description", "phone", "whatsappNo", "email", "address", "city", "area", "latitude", "longitude", "workingRadiusKm", "fulfillmentMode", "controllerAccountsEnabled", "garageType", "supportedBrands", "excludedServiceBrands", "openingTime", "closingTime", "isVerified"];
  const data = Object.fromEntries(allowed.filter((key) => payload[key] !== undefined).map((key) => [key, payload[key]]));

  if (Array.isArray(data.excludedServiceBrands)) {
    const uniqueBrands = new Map();
    data.excludedServiceBrands.forEach((value) => {
      const brand = String(value || "").trim();
      if (brand && brand.toUpperCase() !== "ALL") {
        uniqueBrands.set(brand.toLocaleLowerCase(), brand);
      }
    });
    data.excludedServiceBrands = [...uniqueBrands.values()];
  }
  const ownerFieldMap = {
    ownerName: "name",
    ownerEmail: "email",
    ownerPhone: "phone",
  };
  const ownerData = Object.fromEntries(
    Object.entries(ownerFieldMap)
      .filter(([payloadKey]) => payload[payloadKey] !== undefined)
      .map(([payloadKey, ownerKey]) => [ownerKey, payload[payloadKey]]),
  );

  if (!Object.keys(data).length && !Object.keys(ownerData).length) {
    throw new ApiError(400, "No garage changes were provided");
  }

  if (Object.keys(ownerData).length && !existingGarage.ownerId) {
    throw new ApiError(400, "This garage does not have a linked owner account");
  }

  await prisma.$transaction(async (tx) => {
    if (Object.keys(data).length) {
      await tx.garage.update({ where: { id: garageId }, data });

      if (data.controllerAccountsEnabled === false) {
        const controllerIds = await tx.garageController.findMany({
          where: { garageId, deletedAt: null },
          select: { id: true },
        });
        const ids = controllerIds.map((item) => item.id);
        if (ids.length) {
          await tx.garageControllerSession.updateMany({
            where: { garageControllerId: { in: ids }, revokedAt: null },
            data: { revokedAt: new Date() },
          });
        }
      }

      if (data.controllerAccountsEnabled === true) {
        await tx.garageWorkerTask.updateMany({
          where: { garageId, status: { in: ["ACTIVE", "IN_PROGRESS"] } },
          data: { status: "REVOKED", revokedAt: new Date() },
        });
      }
    }
    if (Object.keys(ownerData).length) {
      await tx.garageOwner.update({
        where: { id: existingGarage.ownerId },
        data: ownerData,
      });
    }
  });
  await invalidateGarageAdminChanges(garageId);
  return getGarage(garageId);
};

const setGarageThumbnail = async (garageId, imageId) => {
  const image = await prisma.garageImage.findFirst({ where: { id: imageId, garageId } });
  if (!image) throw new ApiError(404, "Garage photo not found");
  await prisma.$transaction([
    prisma.garageImage.updateMany({ where: { garageId }, data: { isThumbnail: false } }),
    prisma.garageImage.update({ where: { id: imageId }, data: { isThumbnail: true, order: 0 } }),
  ]);
  const images = await prisma.garageImage.findMany({ where: { garageId }, orderBy: [{ isThumbnail: "desc" }, { order: "asc" }] });
  await prisma.$transaction(images.map((item, index) => prisma.garageImage.update({ where: { id: item.id }, data: { order: index } })));
  await invalidateGarageAdminChanges(garageId);
  return getGarage(garageId);
};

const reorderGarageImages = async (garageId, imageIds = []) => {
  const images = await prisma.garageImage.findMany({ where: { garageId }, select: { id: true, isThumbnail: true } });
  if (images.length !== imageIds.length || new Set(imageIds).size !== imageIds.length || imageIds.some((id) => !images.some((image) => image.id === id))) {
    throw new ApiError(400, "Photo order must include every garage photo exactly once");
  }
  const thumbnailId = images.find((image) => image.isThumbnail)?.id || imageIds[0];
  await prisma.$transaction(imageIds.map((id, index) => prisma.garageImage.update({ where: { id }, data: { order: index, isThumbnail: id === thumbnailId } })));
  await invalidateGarageAdminChanges(garageId);
  return getGarage(garageId);
};

const setGarageActiveStatus = async (garageId, isActive, staff) => {
  await garageOperationalService.setGarageOperationalStatus({
    garageId,
    status: isActive === true ? "ACTIVE" : "PERMANENTLY_BLOCKED",
    reason: isActive === true ? "" : "Disabled from the admin garage list",
    staff,
  });
  return getGarage(garageId);
};

const listAssignableServices = async (query = {}) => {
  return prisma.service.findMany({
    where: {
      isActive: true,
      ...(query.search && {
        OR: [
          { name: { contains: query.search, mode: "insensitive" } },
          { description: { contains: query.search, mode: "insensitive" } },
        ],
      }),
      ...(query.categoryId && { categoryId: query.categoryId }),
    },
    include: { category: true },
    orderBy: [{ category: { name: "asc" } }, { name: "asc" }],
  });
};

const upsertGarageService = async (garageId, payload) => {
  await getGarage(garageId);

  const service = await prisma.service.findUnique({ where: { id: payload.serviceId } });
  if (!service) throw new ApiError(404, "Service not found");

  const isExcluded = parseBoolean(payload.isExcluded, false);
  const hasBatchScopes = Array.isArray(payload.vehicleScopes);
  const rawScopes = hasBatchScopes
    ? payload.vehicleScopes
    : [
        {
          vehicleBrand: payload.vehicleBrand,
          vehicleModel: payload.vehicleModel,
        },
      ];

  if (!rawScopes.length || rawScopes.length > 100) {
    throw new ApiError(400, "Select between 1 and 100 vehicle scopes");
  }

  const uniqueScopes = new Map();
  rawScopes.forEach((scope = {}) => {
    const normalizedScope = normalizeVehicleScope(
      scope.vehicleBrand,
      scope.vehicleModel,
    );
    const scopeKey = `${normalizedScope.vehicleBrand.toLocaleLowerCase()}::${normalizedScope.vehicleModel.toLocaleLowerCase()}`;
    uniqueScopes.set(scopeKey, normalizedScope);
  });
  const vehicleScopes = [...uniqueScopes.values()];

  if (isExcluded && vehicleScopes.some(({ vehicleBrand }) => vehicleBrand === "ALL")) {
    throw new ApiError(400, "Choose specific vehicle brands to exclude");
  }

  const isActive = parseBoolean(payload.isActive, true);
  const garageServices = await prisma.$transaction(
    vehicleScopes.map(({ vehicleBrand, vehicleModel }) =>
      prisma.garageService.upsert({
        where: {
          garageId_serviceId_vehicleBrand_vehicleModel: {
            garageId,
            serviceId: payload.serviceId,
            vehicleBrand,
            vehicleModel,
          },
        },
        create: {
          garageId,
          serviceId: payload.serviceId,
          vehicleBrand,
          vehicleModel,
          isExcluded,
          price: null,
          isActive,
        },
        update: {
          isExcluded,
          isActive,
        },
        include: {
          service: {
            include: { category: true },
          },
        },
      }),
    ),
  );

  await Promise.all([
    deleteCache(`garages:${garageId}:services`),
    deleteCache(`garages:detail:${garageId}`),
    deletePattern("garages:list:*"),
    deletePattern("garages:public:*"),
  ]);

  return hasBatchScopes ? garageServices : garageServices[0];
};

const removeGarageService = async (garageId, serviceId, scope = {}) => {
  await getGarage(garageId);
  const { vehicleBrand, vehicleModel } = normalizeVehicleScope(
    scope.vehicleBrand,
    scope.vehicleModel,
  );

  const garageService = await prisma.garageService.findUnique({
    where: {
      garageId_serviceId_vehicleBrand_vehicleModel: {
        garageId,
        serviceId,
        vehicleBrand,
        vehicleModel,
      },
    },
  });

  if (!garageService) throw new ApiError(404, "Garage service not found");

  const deleted = await prisma.garageService.delete({
    where: { id: garageService.id },
    include: {
      service: {
        include: { category: true },
      },
    },
  });

  await Promise.all([
    deleteCache(`garages:${garageId}:services`),
    deleteCache(`garages:detail:${garageId}`),
    deletePattern("garages:list:*"),
    deletePattern("garages:public:*"),
  ]);

  return deleted;
};

const deleteGarages = async (garageIds = []) => {
  const ids = Array.isArray(garageIds) ? garageIds.filter(Boolean) : [];
  if (!ids.length) throw new ApiError(400, "Select at least one garage to delete");
  return deleteGaragesDeep({ garageIds: ids });
};

module.exports = {
  deleteGarages,
  getGarage,
  listAssignableServices,
  listGarages,
  removeGarageService,
  setGarageActiveStatus,
  updateGarageDetails,
  setGarageThumbnail,
  reorderGarageImages,
  upsertGarageService,
};
