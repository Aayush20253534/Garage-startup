const {
  calculatePlatformFee: calculateNormalPlatformFee,
} = require("../utils/platformFee");

const GARAGE_MINIMUM_ACTIVATION_RECHARGE = 100;
const GARAGE_MAXIMUM_IMAGES = 15;
const GARAGE_MAX_IMAGE_SIZE_BYTES = 2 * 1024 * 1024;
const MIN_BOOKING_INSPECTION_IMAGES = 5;
const MAX_BOOKING_INSPECTION_IMAGES = 15;
const REQUIRED_BOOKING_INSPECTION_VIDEOS = 1;
const MAX_BOOKING_INSPECTION_VIDEO_SIZE_BYTES = 50 * 1024 * 1024;
// Kept for callers that still use the old constant name. It represents the minimum.
const REQUIRED_BOOKING_INSPECTION_IMAGES = MIN_BOOKING_INSPECTION_IMAGES;

const calculatePlatformFee = (serviceUpperLimit, requestType = "NORMAL") => {
  if (requestType === "SOS") return 50;

  return calculateNormalPlatformFee(serviceUpperLimit);
};

module.exports = {
  GARAGE_MINIMUM_ACTIVATION_RECHARGE,
  GARAGE_MAXIMUM_IMAGES,
  GARAGE_MAX_IMAGE_SIZE_BYTES,
  MIN_BOOKING_INSPECTION_IMAGES,
  MAX_BOOKING_INSPECTION_IMAGES,
  REQUIRED_BOOKING_INSPECTION_IMAGES,
  REQUIRED_BOOKING_INSPECTION_VIDEOS,
  MAX_BOOKING_INSPECTION_VIDEO_SIZE_BYTES,
  calculatePlatformFee,
};
