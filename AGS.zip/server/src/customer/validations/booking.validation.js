const { body, param } = require("express-validator");
const { SERVICE_FULFILLMENT_TYPES } = require("../../constants/serviceFulfillmentType");

const bookingIdValidation = [
  param("id").isUUID().withMessage("Invalid booking ID"),
];

const acceptDeliveryValidation = [
  ...bookingIdValidation,
  body("paymentMethod")
    .trim()
    .toUpperCase()
    .isIn(["CASH", "UPI"])
    .withMessage("Choose Cash or UPI as the final payment mode"),
  body("finalAmount")
    .exists({ checkFalsy: true })
    .withMessage("Final service amount is required")
    .bail()
    .custom((value) => {
      const amount = Number(value);
      return Number.isFinite(amount) && amount > 0;
    })
    .withMessage("Final service amount must be greater than zero"),
];

const createBookingValidation = [
  body("vehicleId").isUUID().withMessage("Valid vehicle ID is required"),

  body("serviceIds")
    .isArray({ min: 1 })
    .withMessage("At least one service is required"),

  body("serviceIds.*").isUUID().withMessage("Each service ID must be valid"),

  body("fulfillmentType")
    .optional({ nullable: true, checkFalsy: true })
    .isIn(SERVICE_FULFILLMENT_TYPES)
    .withMessage("Choose pickup & delivery or self drop-off & pickup"),

  body("scheduledDate")
    .optional({ nullable: true, checkFalsy: true })
    .isISO8601()
    .withMessage("Scheduled date must be valid"),

  body("startTime")
    .optional({ nullable: true, checkFalsy: true })
    .trim(),

  body("endTime")
    .optional({ nullable: true, checkFalsy: true })
    .trim(),

  body("customerNote")
    .optional({ nullable: true, checkFalsy: true })
    .trim(),

  body("location")
    .notEmpty()
    .withMessage("Customer location is required")
    .isObject()
    .withMessage("Location must be an object"),

  body("location.latitude")
    .isFloat({ min: -90, max: 90 })
    .withMessage("Valid latitude is required"),

  body("location.longitude")
    .isFloat({ min: -180, max: 180 })
    .withMessage("Valid longitude is required"),

  body("location.address")
    .optional({ nullable: true, checkFalsy: true })
    .trim(),

  body("location.city")
    .optional({ nullable: true, checkFalsy: true })
    .trim(),

  body("location.placeId")
    .optional({ nullable: true, checkFalsy: true })
    .trim()
    .isLength({ max: 300 }),

  body("useWalletCoins")
    .optional({ nullable: true })
    .isInt({ min: 0 })
    .withMessage("Wallet coins must be a positive number"),
];

module.exports = {
  bookingIdValidation,
  createBookingValidation,
  acceptDeliveryValidation,
};
