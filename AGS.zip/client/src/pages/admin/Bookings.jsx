import { useEffect, useState } from "react";
import { adminApi } from "@/api/admin";
import { mapsApi } from "@/api/maps";
import StaticMapPreview from "@/components/maps/StaticMapPreview";
import BookingManagementModal from "@/components/admin/BookingManagementModal";
import { useApp } from "@/hooks/useApp";
import { formatRupees } from "@/utils/priceRange";
import {
  FiAlertCircle,
  FiCalendar,
  FiEye,
  FiMap,
  FiNavigation,
  FiRefreshCw,
  FiSearch,
  FiTrash2,
  FiX,
} from "react-icons/fi";

const CLEAR_CONFIRMATION = "CLEAR ALL BOOKINGS";

const activeStatuses = [
  "",
  "SEARCHING_GARAGE",
  "GARAGE_ASSIGNED",
  "CONFIRMED",
  "IN_PROGRESS",
  "COMPLETED",
  "CANCELLED",
  "EXPIRED",
];


const formatStatus = (status) => status?.replaceAll("_", " ") || "-";

const getBookingAmount = (booking) =>
  Number(booking.payableAmount || booking.payment?.amount || 0);

const formatVehicle = (vehicle) => {
  if (!vehicle) return "-";

  return (
    `${vehicle.brand || ""} ${vehicle.model || ""}`.trim() ||
    "-"
  );
};

const getStatusClass = (status) => {
  if (["COMPLETED", "CONFIRMED"].includes(status)) {
    return "bg-lime-100 text-ink";
  }

  if (["CANCELLED", "EXPIRED"].includes(status)) {
    return "bg-red-50 text-red-700";
  }

  if (["IN_PROGRESS", "GARAGE_ASSIGNED"].includes(status)) {
    return "bg-blue-50 text-blue-700";
  }

  return "bg-bg-soft text-muted";
};

export default function Bookings({
  fixedStatus = "",
  title = "Bookings",
  description = "Inspect bookings across customers and garages.",
  showStatusFilter = true,
  showBulkActions = true,
} = {}) {
  const { user } = useApp();

  const [bookings, setBookings] = useState([]);
  const [filters, setFilters] = useState({
    search: "",
    status: "",
  });
  const [loading, setLoading] = useState(false);
  const [clearing, setClearing] = useState(false);
  const [showClearDialog, setShowClearDialog] =
    useState(false);
  const [confirmation, setConfirmation] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [optimizing, setOptimizing] = useState(false);
  const [optimization, setOptimization] = useState(null);
  const [showOptimization, setShowOptimization] = useState(false);
  const [selectedBookingId, setSelectedBookingId] = useState("");

  const isAdmin =
    user?.accountType === "STAFF" &&
    ["ADMIN", "SUB_ADMIN"].includes(user?.role);

  const load = async () => {
    setLoading(true);
    setError("");

    try {
      const params = Object.fromEntries(
        Object.entries({
          ...filters,
          ...(fixedStatus && { status: fixedStatus }),
        }).filter(([, value]) => value),
      );

      const data = await adminApi.getBookings(params);
      setBookings(data || []);
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Unable to load bookings",
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const openClearDialog = () => {
    setConfirmation("");
    setError("");
    setSuccess("");
    setShowClearDialog(true);
  };

  const closeClearDialog = () => {
    if (clearing) return;

    setShowClearDialog(false);
    setConfirmation("");
  };

  const clearAllBookings = async (event) => {
    event.preventDefault();

    if (
      !isAdmin ||
      confirmation !== CLEAR_CONFIRMATION
    ) {
      return;
    }

    setClearing(true);
    setError("");
    setSuccess("");

    try {
      const result = await adminApi.clearAllBookings(
        confirmation,
      );

      const deletedBookings = Number(
        result?.deletedBookings || 0,
      );

      const failedCloudImages = Number(
        result?.cloudinaryInspectionImages?.failed || 0,
      );

      setSuccess(
        deletedBookings
          ? `${deletedBookings} booking${
              deletedBookings === 1 ? "" : "s"
            } cleared across all customers and garages.${
              failedCloudImages
                ? ` ${failedCloudImages} inspection image${
                    failedCloudImages === 1 ? "" : "s"
                  } could not be removed from Cloudinary.`
                : ""
            }`
          : "There were no bookings to clear.",
      );

      setBookings([]);
      setFilters({ search: "", status: "" });
      setShowClearDialog(false);
      setConfirmation("");
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Unable to clear all bookings",
      );
    } finally {
      setClearing(false);
    }
  };

  const optimizeActiveRoutes = async () => {
    if (!isAdmin) return;

    try {
      setOptimizing(true);
      setError("");
      setSuccess("");
      const activeIds = bookings
        .filter((booking) =>
          ["GARAGE_ASSIGNED", "CONFIRMED", "IN_PROGRESS"].includes(
            booking.status,
          ),
        )
        .map((booking) => booking.id);
      const result = await mapsApi.optimizeRoutes(activeIds);
      setOptimization(result);
      setShowOptimization(true);
    } catch (err) {
      setError(
        err.response?.data?.message ||
          err.message ||
          "Unable to optimize active garage routes",
      );
    } finally {
      setOptimizing(false);
    }
  };

  return (
    <div className="mx-auto max-w-6xl space-y-4 overflow-x-hidden">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-start">
        <div>
          <h2 className="text-2xl font-bold text-ink">
            {title}
          </h2>
          <p className="mt-1 text-sm text-muted">
            {description}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {showBulkActions && isAdmin && (
            <button
              type="button"
              onClick={optimizeActiveRoutes}
              disabled={loading || clearing || optimizing}
              className="inline-flex h-10 items-center gap-2 rounded-lg bg-ink px-3 text-sm font-semibold text-white transition hover:bg-ink-2 disabled:cursor-not-allowed disabled:opacity-60"
            >
              <FiNavigation className={optimizing ? "animate-pulse" : ""} />
              {optimizing ? "Optimizing…" : "Optimize active routes"}
            </button>
          )}

          {showBulkActions && isAdmin && (
            <button
              type="button"
              onClick={openClearDialog}
              disabled={loading || clearing}
              className="inline-flex h-10 items-center gap-2 rounded-lg border border-red-200 bg-red-50 px-3 text-sm font-semibold text-red-700 transition hover:border-red-300 hover:bg-red-100 disabled:cursor-not-allowed disabled:opacity-60"
            >
              <FiTrash2 />
              Clear all bookings
            </button>
          )}

          <button
            type="button"
            onClick={load}
            disabled={loading || clearing}
            className="hidden h-10 items-center gap-2 rounded-lg border border-line px-3 text-sm font-semibold text-ink transition hover:border-ink hover:bg-bg-soft disabled:cursor-not-allowed disabled:opacity-60 sm:inline-flex"
          >
            <FiRefreshCw
              className={loading ? "animate-spin" : ""}
            />
            Refresh
          </button>
        </div>
      </div>

      {error && (
        <div className="flex items-center gap-2 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          <FiAlertCircle className="shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="rounded-lg border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-700">
          {success}
        </div>
      )}

      <section className="card-soft rounded-2xl p-4 shadow-sm">
        <div
          className={
            showStatusFilter
              ? "grid gap-3 md:grid-cols-[minmax(0,1fr)_240px_auto]"
              : "grid gap-3 md:grid-cols-[minmax(0,1fr)_auto]"
          }
        >
          <label className="relative min-w-0">
            <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
            <input
              value={filters.search}
              onChange={(event) =>
                setFilters({
                  ...filters,
                  search: event.target.value,
                })
              }
              placeholder="Search booking, customer, garage"
              className="h-10 w-full rounded-lg border border-line pl-10 pr-3 text-sm outline-none transition focus:border-ink"
            />
          </label>

          {showStatusFilter && (
            <select
              value={filters.status}
              onChange={(event) =>
                setFilters({
                  ...filters,
                  status: event.target.value,
                })
              }
              className="h-10 min-w-0 rounded-lg border border-line px-3 text-sm outline-none transition focus:border-ink"
            >
              {activeStatuses.map((status) => (
                <option
                  key={status || "all"}
                  value={status}
                >
                  {status
                    ? formatStatus(status)
                    : "All active statuses"}
                </option>
              ))}
            </select>
          )}

          <button
            type="button"
            onClick={load}
            disabled={loading || clearing}
            className="inline-flex h-10 items-center justify-center gap-2 rounded-lg border border-line px-4 text-sm font-semibold text-ink transition hover:border-ink hover:bg-bg-soft disabled:cursor-not-allowed disabled:opacity-60"
          >
            <FiRefreshCw
              className={loading ? "animate-spin" : ""}
            />
            Search
          </button>
        </div>
      </section>

      <section className="card-soft overflow-hidden rounded-2xl shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[780px] text-sm">
            <thead className="bg-bg-soft text-left text-xs uppercase tracking-wide text-muted">
              <tr>
                {[
                  "Booking",
                  "Customer",
                  "Garage",
                  "Vehicle",
                  "Status",
                  "Amount",
                  "Created",
                  "Actions",
                ].map((heading) => (
                  <th
                    key={heading}
                    className="whitespace-nowrap px-4 py-3 font-bold"
                  >
                    {heading}
                  </th>
                ))}
              </tr>
            </thead>

            <tbody>
              {loading ? (
                <tr>
                  <td
                    colSpan="8"
                    className="px-4 py-6 text-sm text-muted"
                  >
                    Loading bookings...
                  </td>
                </tr>
              ) : bookings.length ? (
                bookings.map((booking) => (
                  <tr
                    key={booking.id}
                    className="border-t border-line transition hover:bg-bg-soft/70"
                  >
                    <td className="whitespace-nowrap px-4 py-3 font-semibold text-ink">
                      <div className="flex items-center gap-2">
                        <FiCalendar className="text-muted" />
                        <span>
                          #
                          {booking.bookingCode ||
                            booking.id?.slice(0, 8)}
                        </span>
                      </div>
                    </td>

                    <td className="whitespace-nowrap px-4 py-3 text-muted">
                      {booking.user?.name || "-"}
                    </td>

                    <td className="whitespace-nowrap px-4 py-3 text-muted">
                      {booking.garage?.name ||
                        "Unassigned"}
                    </td>

                    <td className="whitespace-nowrap px-4 py-3 text-muted">
                      {formatVehicle(booking.vehicle)}
                    </td>

                    <td className="whitespace-nowrap px-4 py-3">
                      <span
                        className={[
                          "rounded-full px-2.5 py-1 text-xs font-bold",
                          getStatusClass(booking.status),
                        ].join(" ")}
                      >
                        {formatStatus(booking.status)}
                      </span>
                    </td>

                    <td className="whitespace-nowrap px-4 py-3 font-semibold">
                      {formatRupees(getBookingAmount(booking))}
                    </td>

                    <td className="whitespace-nowrap px-4 py-3 text-muted">
                      {booking.createdAt
                        ? new Date(
                            booking.createdAt,
                          ).toLocaleDateString()
                        : "-"}
                    </td>

                    <td className="whitespace-nowrap px-4 py-3">
                      <button
                        type="button"
                        onClick={() => setSelectedBookingId(booking.id)}
                        className="inline-flex h-9 items-center gap-2 rounded-lg border border-line bg-white px-3 text-xs font-bold text-ink transition hover:border-ink hover:bg-bg-soft"
                      >
                        <FiEye />
                        View & manage
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td
                    colSpan="8"
                    className="px-4 py-6 text-sm text-muted"
                  >
                    No bookings found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {showBulkActions && showOptimization && isAdmin && optimization && (
        <div
          className="fixed inset-0 z-[100] overflow-y-auto bg-black/65 px-4 py-8"
          role="presentation"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) {
              setShowOptimization(false);
            }
          }}
        >
          <section className="mx-auto w-full max-w-6xl rounded-3xl bg-bg-soft p-4 shadow-2xl sm:p-6">
            <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-start">
              <div>
                <p className="text-xs font-bold uppercase tracking-widest text-muted">
                  Admin route optimization
                </p>
                <h3 className="mt-1 text-2xl font-bold text-ink">
                  Optimized garage dispatch plan
                </h3>
                <p className="mt-2 max-w-3xl text-sm text-muted">
                  Active assigned bookings are grouped by garage and sequenced
                  through Google Route Optimization. This is a planning view and
                  does not silently reassign bookings.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowOptimization(false)}
                className="rounded-xl border border-line bg-white p-3 text-muted transition hover:text-ink"
              >
                <FiX />
              </button>
            </div>

            <div className="mt-6 grid gap-5">
              {optimization.routes?.length ? (
                optimization.routes.map((route, routeIndex) => (
                  <article
                    key={`${route.garage?.id || routeIndex}`}
                    className="grid gap-5 rounded-3xl border border-line bg-white p-5 lg:grid-cols-[340px_minmax(0,1fr)]"
                  >
                    <StaticMapPreview
                      origin={route.garage}
                      destination={route.visits?.at(-1)}
                      points={route.visits || []}
                      title={route.garage?.name || `Route ${routeIndex + 1}`}
                    />

                    <div>
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div>
                          <p className="text-xs font-bold uppercase tracking-wide text-muted">
                            Garage route {routeIndex + 1}
                          </p>
                          <h4 className="mt-1 text-xl font-bold">
                            {route.garage?.name || "Assigned garage"}
                          </h4>
                        </div>
                        <span className="inline-flex items-center gap-2 rounded-full bg-brand/20 px-3 py-1.5 text-xs font-bold">
                          <FiMap /> {route.visits?.length || 0} stop{route.visits?.length === 1 ? "" : "s"}
                        </span>
                      </div>

                      <div className="mt-5 grid gap-3">
                        {(route.visits || []).map((visit) => (
                          <div
                            key={`${visit.bookingId}-${visit.order}`}
                            className="flex items-start gap-4 rounded-2xl bg-bg-soft p-4"
                          >
                            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-ink text-sm font-bold text-white">
                              {visit.order}
                            </span>
                            <div className="min-w-0 flex-1">
                              <div className="flex flex-wrap items-center justify-between gap-2">
                                <h5 className="font-bold">
                                  #{visit.bookingCode || visit.bookingId?.slice(0, 8)}
                                </h5>
                                <span className="text-xs font-semibold text-muted">
                                  {visit.startTime
                                    ? new Date(visit.startTime).toLocaleTimeString("en-IN", {
                                        hour: "2-digit",
                                        minute: "2-digit",
                                      })
                                    : "Time pending"}
                                </span>
                              </div>
                              <p className="mt-1 text-sm font-semibold">
                                {visit.customerName}
                              </p>
                              <p className="mt-1 text-xs text-muted">
                                {visit.customerAddress || "Customer coordinates confirmed"}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </article>
                ))
              ) : (
                <div className="rounded-2xl border border-line bg-white p-6 text-sm text-muted">
                  No optimized routes were returned.
                </div>
              )}

              {optimization.skippedBookings?.length > 0 && (
                <div className="rounded-2xl border border-amber-200 bg-amber-50 p-5 text-sm text-amber-900">
                  <h4 className="font-bold">Skipped bookings</h4>
                  <p className="mt-1">
                    {optimization.skippedBookings.length} booking(s) could not be
                    included. Review their garage assignment and coordinates.
                  </p>
                </div>
              )}
            </div>
          </section>
        </div>
      )}

      {selectedBookingId && (
        <BookingManagementModal
          bookingId={selectedBookingId}
          isAdmin={isAdmin}
          onClose={() => setSelectedBookingId("")}
          onUpdated={(updatedBooking) => {
            setBookings((current) =>
              current.map((booking) =>
                booking.id === updatedBooking.id
                  ? { ...booking, ...updatedBooking }
                  : booking,
              ),
            );
          }}
        />
      )}

      {showBulkActions && showClearDialog && isAdmin && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 px-4 py-8"
          role="presentation"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) {
              closeClearDialog();
            }
          }}
        >
          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby="clear-bookings-title"
            className="w-full max-w-lg rounded-2xl border border-red-200 bg-white p-5 shadow-2xl sm:p-6"
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-red-600">
                  Admin-only destructive action
                </p>
                <h3
                  id="clear-bookings-title"
                  className="mt-1 text-xl font-bold text-ink"
                >
                  Clear every booking?
                </h3>
              </div>

              <button
                type="button"
                onClick={closeClearDialog}
                disabled={clearing}
                aria-label="Close"
                className="rounded-lg p-2 text-muted transition hover:bg-bg-soft hover:text-ink disabled:opacity-50"
              >
                <FiX />
              </button>
            </div>

            <div className="mt-4 rounded-xl border border-red-100 bg-red-50 p-4 text-sm leading-6 text-red-800">
              <p>
                This removes bookings for every customer and
                garage, including related payments, selected
                services, broadcasts, reviews, and inspection
                image records.
              </p>
              <p className="mt-2">
                Complaints are preserved but detached from their
                deleted booking. Wallet balances and wallet
                transaction history are not changed.
              </p>
              <p className="mt-2 font-semibold">
                This action cannot be undone.
              </p>
            </div>

            <form
              onSubmit={clearAllBookings}
              className="mt-5"
            >
              <label className="grid gap-2 text-sm font-medium text-ink">
                Type{" "}
                <span className="font-mono font-bold text-red-700">
                  {CLEAR_CONFIRMATION}
                </span>{" "}
                to confirm
                <input
                  autoFocus
                  value={confirmation}
                  onChange={(event) =>
                    setConfirmation(event.target.value)
                  }
                  autoComplete="off"
                  className="h-11 rounded-lg border border-line px-3 font-mono text-sm outline-none transition focus:border-red-500"
                />
              </label>

              <div className="mt-5 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
                <button
                  type="button"
                  onClick={closeClearDialog}
                  disabled={clearing}
                  className="h-10 rounded-lg border border-line px-4 text-sm font-semibold text-ink transition hover:border-ink hover:bg-bg-soft disabled:opacity-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={
                    clearing ||
                    confirmation !==
                      CLEAR_CONFIRMATION
                  }
                  className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-red-600 px-4 text-sm font-semibold text-white transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <FiTrash2 />
                  {clearing
                    ? "Clearing bookings..."
                    : "Clear all bookings"}
                </button>
              </div>
            </form>
          </section>
        </div>
      )}
    </div>
  );
}
