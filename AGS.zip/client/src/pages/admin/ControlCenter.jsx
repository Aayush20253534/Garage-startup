import { useEffect, useMemo, useState } from "react";
import { adminApi } from "@/api/admin";
import { cityApi } from "@/api/cities";
import BookingManagementModal from "@/components/admin/BookingManagementModal";
import { formatRupees } from "@/utils/priceRange";
import {
  FiActivity,
  FiAlertCircle,
  FiBarChart2,
  FiBell,
  FiCheck,
  FiClock,
  FiDownload,
  FiEye,
  FiFileText,
  FiRefreshCw,
  FiSave,
  FiSearch,
  FiShield,
  FiSlash,
  FiTrash2,
  FiUpload,
  FiUsers,
  FiX,
} from "react-icons/fi";

const tabs = [
  ["escalations", "Escalations", FiAlertCircle],
  ["support", "Booking Support", FiUsers],
  ["garages", "Garage Performance", FiBarChart2],
  ["pricing", "Pricing Control", FiActivity],
  ["availability", "Availability", FiClock],
  ["audit", "Audit Logs", FiFileText],
];

const operationalStatuses = [
  "ACTIVE",
  "TEMPORARILY_SUSPENDED",
  "UNDER_REVIEW",
  "DOCUMENTS_EXPIRED",
  "PERMANENTLY_BLOCKED",
];
const fuelTypes = ["", "PETROL", "DIESEL", "ELECTRIC", "HYBRID", "CNG", "OTHER"];
const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

const fieldClass = "h-10 rounded-lg border border-line bg-white px-3 text-sm outline-none focus:border-ink";
const buttonClass = "inline-flex h-10 items-center justify-center gap-2 rounded-lg px-4 text-sm font-bold transition disabled:cursor-not-allowed disabled:opacity-50";
const emptyCoverageFilters = {
  city: "",
  serviceId: "",
  vehicleBrand: "",
  fuelType: "",
};
const buildCoverageParams = (filters = {}) => ({
  ...Object.fromEntries(
    Object.entries(filters).filter(([, value]) => String(value || "").trim()),
  ),
  limit: 500,
});

const formatDateTime = (value) => {
  if (!value) return "-";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "-" : date.toLocaleString();
};
const formatStatus = (value) => String(value || "-").replaceAll("_", " ");
const statusTone = (status) => {
  const value = String(status || "");
  if (["ACTIVE", "COMPLETED", "RESOLVED", "APPLIED"].includes(value)) return "border-green-200 bg-green-50 text-green-700";
  if (["HIGH", "CRITICAL", "PERMANENTLY_BLOCKED", "DOCUMENTS_EXPIRED", "CANCELLED"].includes(value)) return "border-red-200 bg-red-50 text-red-700";
  if (["ACKNOWLEDGED", "TEMPORARILY_SUSPENDED", "PENDING"].includes(value)) return "border-amber-200 bg-amber-50 text-amber-800";
  return "border-blue-200 bg-blue-50 text-blue-700";
};

function Badge({ value }) {
  const permanentlyBlocked = String(value || "") === "PERMANENTLY_BLOCKED";
  return (
    <span
      className={`inline-flex border font-bold ${
        permanentlyBlocked
          ? "min-w-[154px] justify-center rounded-none border-l-4 px-3 py-2 text-[11px] uppercase tracking-wide"
          : "rounded-md px-2.5 py-1 text-xs"
      } ${statusTone(value)}`}
    >
      {formatStatus(value)}
    </span>
  );
}

function StatCard({ label, value, hint }) {
  return (
    <article className="rounded-2xl border border-line bg-white p-4 shadow-sm">
      <p className="text-xs font-bold uppercase tracking-wide text-muted">{label}</p>
      <p className="mt-2 text-2xl font-extrabold text-ink">{value ?? 0}</p>
      {hint && <p className="mt-1 text-xs text-muted">{hint}</p>}
    </article>
  );
}

function Section({ title, description, actions, children }) {
  return (
    <section className="rounded-2xl border border-line bg-white p-4 shadow-sm sm:p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-lg font-extrabold text-ink">{title}</h2>
          {description && <p className="mt-1 text-sm text-muted">{description}</p>}
        </div>
        {actions}
      </div>
      <div className="mt-5">{children}</div>
    </section>
  );
}

const parseCsv = (text) => {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    const next = text[index + 1];
    if (char === '"' && quoted && next === '"') {
      cell += '"';
      index += 1;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (char === "," && !quoted) {
      row.push(cell);
      cell = "";
    } else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && next === "\n") index += 1;
      row.push(cell);
      if (row.some((value) => value.trim())) rows.push(row);
      row = [];
      cell = "";
    } else {
      cell += char;
    }
  }
  row.push(cell);
  if (row.some((value) => value.trim())) rows.push(row);
  if (rows.length < 2) return [];
  const headers = rows[0].map((header) => header.trim());
  return rows.slice(1).map((values) => Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ""])));
};

export default function ControlCenter() {
  const availableOperationalStatuses = operationalStatuses;
  const [tab, setTab] = useState("escalations");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [overview, setOverview] = useState({});
  const [escalations, setEscalations] = useState([]);
  const [escalationRules, setEscalationRules] = useState([]);
  const [supportSearch, setSupportSearch] = useState("");
  const [supportBookings, setSupportBookings] = useState([]);
  const [selectedBookingId, setSelectedBookingId] = useState("");
  const [performance, setPerformance] = useState([]);
  const [performanceDays, setPerformanceDays] = useState(30);
  const [garageStatusDrafts, setGarageStatusDrafts] = useState({});
  const [coverage, setCoverage] = useState(null);
  const [coverageFilters, setCoverageFilters] = useState(emptyCoverageFilters);
  const [schedules, setSchedules] = useState([]);
  const [availabilityRules, setAvailabilityRules] = useState([]);
  const [auditLogs, setAuditLogs] = useState([]);
  const [auditSearch, setAuditSearch] = useState("");
  const [auditRole, setAuditRole] = useState("");
  const [services, setServices] = useState([]);
  const [cities, setCities] = useState([]);
  const [garages, setGarages] = useState([]);
  const [importPreview, setImportPreview] = useState(null);
  const [importRows, setImportRows] = useState([]);
  const [scheduleForm, setScheduleForm] = useState({
    city: "",
    serviceId: "",
    vehicleBrand: "ALL",
    vehicleModel: "",
    fuelType: "",
    minPrice: "",
    maxPrice: "",
    startsAt: "",
    endsAt: "",
    isActive: true,
  });
  const [ruleForm, setRuleForm] = useState({
    serviceId: "",
    cityId: "",
    garageId: "",
    vehicleBrand: "",
    vehicleModel: "",
    fuelType: "",
    dayOfWeek: "",
    startTime: "",
    endTime: "",
    effect: "DENY",
    reason: "",
    isActive: true,
  });

  const showError = (err, fallback) => setError(err?.response?.data?.message || err?.message || fallback);
  const clearMessages = () => { setError(""); setSuccess(""); };

  const load = async () => {
    setLoading(true);
    clearMessages();
    try {
      const [overviewData, escalationData, rulesData, performanceData, coverageData, scheduleData, availabilityData, auditData, serviceData, cityData, garageData] = await Promise.all([
        adminApi.getControlCenterOverview(),
        adminApi.getEscalations(),
        adminApi.getEscalationRules(),
        adminApi.getGaragePerformance({ days: performanceDays }),
        adminApi.getPricingCoverage({ limit: 500 }),
        adminApi.getPriceSchedules(),
        adminApi.getAvailabilityRules(),
        adminApi.getAuditLogs({ limit: 150 }),
        adminApi.getAssignableServices(),
        cityApi.getAdminCities({ includeInactive: true }),
        adminApi.getGarages(),
      ]);
      setOverview(overviewData || {});
      setEscalations(escalationData || []);
      setEscalationRules(rulesData || []);
      setPerformance(performanceData || []);
      setCoverage(coverageData || null);
      setSchedules(scheduleData || []);
      setAvailabilityRules(availabilityData || []);
      setAuditLogs(auditData || []);
      setServices(serviceData || []);
      setCities(cityData || []);
      setGarages(Array.isArray(garageData) ? garageData : garageData?.items || []);
    } catch (err) {
      showError(err, "Unable to load the admin control center");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const filteredAuditLogs = useMemo(() => {
    const needle = auditSearch.trim().toLowerCase();
    return auditLogs.filter((log) => {
      if (auditRole && log.actorRole !== auditRole) return false;
      if (!needle) return true;
      return [
        log.actorName,
        log.actorEmail,
        log.actorLoginId,
        log.actorId,
        log.action,
        log.resource,
        log.path,
      ].some((value) => String(value || "").toLowerCase().includes(needle));
    });
  }, [auditLogs, auditRole, auditSearch]);

  const refreshPerformance = async () => {
    setBusy("performance");
    clearMessages();
    try {
      setPerformance(await adminApi.getGaragePerformance({ days: performanceDays }));
    } catch (err) {
      showError(err, "Unable to refresh garage performance");
    } finally {
      setBusy("");
    }
  };

  const refreshCoverage = async (filters = coverageFilters) => {
    setBusy("coverage");
    clearMessages();
    try {
      setCoverage(await adminApi.getPricingCoverage(buildCoverageParams(filters)));
    } catch (err) {
      showError(err, "Unable to refresh price-range coverage");
    } finally {
      setBusy("");
    }
  };

  const resetCoverageFilters = async () => {
    const nextFilters = { ...emptyCoverageFilters };
    setCoverageFilters(nextFilters);
    await refreshCoverage(nextFilters);
  };

  const searchBookings = async (event) => {
    event?.preventDefault();
    if (!supportSearch.trim()) return;
    setBusy("support-search");
    clearMessages();
    try {
      setSupportBookings(await adminApi.searchSupportBookings(supportSearch.trim()));
    } catch (err) {
      showError(err, "Unable to search bookings");
    } finally {
      setBusy("");
    }
  };

  const notifyBooking = async (bookingId, target) => {
    setBusy(`notify:${bookingId}:${target}`);
    clearMessages();
    try {
      await adminApi.resendBookingNotification(bookingId, { target });
      setSuccess(`Booking notification sent to ${target.toLowerCase()}.`);
    } catch (err) {
      showError(err, "Unable to send booking notification");
    } finally {
      setBusy("");
    }
  };

  const updateEscalation = async (item, status) => {
    setBusy(`escalation:${item.id}`);
    clearMessages();
    try {
      await adminApi.updateEscalation(item.id, { status, note: status === "RESOLVED" ? "Resolved from Admin Control Center" : "" });
      setEscalations(await adminApi.getEscalations());
      setOverview(await adminApi.getControlCenterOverview());
      setSuccess(`Escalation ${status.toLowerCase()}.`);
    } catch (err) {
      showError(err, "Unable to update escalation");
    } finally {
      setBusy("");
    }
  };

  const saveEscalationRule = async (rule) => {
    setBusy(`rule:${rule.id}`);
    clearMessages();
    try {
      await adminApi.updateEscalationRule(rule.id, {
        enabled: rule.enabled,
        thresholdMinutes: Number(rule.thresholdMinutes),
        severity: rule.severity,
      });
      setEscalationRules(await adminApi.getEscalationRules());
      setSuccess("Escalation rule updated.");
    } catch (err) {
      showError(err, "Unable to update escalation rule");
    } finally {
      setBusy("");
    }
  };

  const saveGarageStatus = async (garage) => {
    const draft = garageStatusDrafts[garage.id] || { status: garage.operationalStatus, reason: garage.suspensionReason || "", suspendedUntil: "" };
    setBusy(`garage:${garage.id}`);
    clearMessages();
    try {
      await adminApi.setGarageOperationalStatus(garage.id, {
        ...draft,
        suspendedUntil: draft.status === "TEMPORARILY_SUSPENDED" && draft.suspendedUntil
          ? new Date(draft.suspendedUntil).toISOString()
          : null,
      });
      await refreshPerformance();
      setOverview(await adminApi.getControlCenterOverview());
      setSuccess(`${garage.name} status updated.`);
    } catch (err) {
      showError(err, "Unable to update garage status");
    } finally {
      setBusy("");
    }
  };

  const handleCsvFile = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    clearMessages();
    try {
      const rows = parseCsv(await file.text());
      if (!rows.length) throw new Error("CSV must contain a header row and at least one data row");
      setImportRows(rows);
      const preview = await adminApi.importPriceRanges(rows, true);
      setImportPreview(preview);
      if (preview.valid) setSuccess(`${preview.rows} rows are valid and ready to import.`);
    } catch (err) {
      setImportRows([]);
      setImportPreview(null);
      showError(err, "Unable to read CSV");
    }
  };

  const commitImport = async () => {
    setBusy("import");
    clearMessages();
    try {
      const result = await adminApi.importPriceRanges(importRows, false);
      setSuccess(`${result.imported} price ranges imported.`);
      setImportRows([]);
      setImportPreview(null);
      setCoverage(await adminApi.getPricingCoverage(buildCoverageParams(coverageFilters)));
    } catch (err) {
      showError(err, "Unable to import price ranges");
    } finally {
      setBusy("");
    }
  };

  const exportCsv = async () => {
    setBusy("export");
    clearMessages();
    try {
      const response = await adminApi.exportPriceRangesCsv();
      const url = URL.createObjectURL(response.data);
      const link = document.createElement("a");
      link.href = url;
      link.download = `rovauto-price-ranges-${new Date().toISOString().slice(0, 10)}.csv`;
      link.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      showError(err, "Unable to export price ranges");
    } finally {
      setBusy("");
    }
  };

  const createSchedule = async (event) => {
    event.preventDefault();
    setBusy("schedule-create");
    clearMessages();
    try {
      await adminApi.createPriceSchedule({
        ...scheduleForm,
        minPrice: Number(scheduleForm.minPrice),
        maxPrice: Number(scheduleForm.maxPrice),
        startsAt: new Date(scheduleForm.startsAt).toISOString(),
        endsAt: scheduleForm.endsAt ? new Date(scheduleForm.endsAt).toISOString() : null,
      });
      setScheduleForm({ city: "", serviceId: "", vehicleBrand: "ALL", vehicleModel: "", fuelType: "", minPrice: "", maxPrice: "", startsAt: "", endsAt: "", isActive: true });
      setSchedules(await adminApi.getPriceSchedules());
      setSuccess("Price schedule created.");
    } catch (err) {
      showError(err, "Unable to create price schedule");
    } finally {
      setBusy("");
    }
  };

  const cancelSchedule = async (id) => {
    setBusy(`schedule:${id}`);
    clearMessages();
    try {
      await adminApi.cancelPriceSchedule(id);
      setSchedules(await adminApi.getPriceSchedules());
      setSuccess("Price schedule cancelled.");
    } catch (err) {
      showError(err, "Unable to cancel price schedule");
    } finally {
      setBusy("");
    }
  };

  const createAvailabilityRule = async (event) => {
    event.preventDefault();
    setBusy("availability-create");
    clearMessages();
    try {
      await adminApi.createAvailabilityRule({
        ...ruleForm,
        dayOfWeek: ruleForm.dayOfWeek === "" ? null : Number(ruleForm.dayOfWeek),
      });
      setRuleForm({ serviceId: "", cityId: "", garageId: "", vehicleBrand: "", vehicleModel: "", fuelType: "", dayOfWeek: "", startTime: "", endTime: "", effect: "DENY", reason: "", isActive: true });
      setAvailabilityRules(await adminApi.getAvailabilityRules());
      setOverview(await adminApi.getControlCenterOverview());
      setSuccess("Availability rule created.");
    } catch (err) {
      showError(err, "Unable to create availability rule");
    } finally {
      setBusy("");
    }
  };

  const toggleAvailabilityRule = async (rule) => {
    setBusy(`availability:${rule.id}`);
    clearMessages();
    try {
      await adminApi.updateAvailabilityRule(rule.id, { isActive: !rule.isActive });
      setAvailabilityRules(await adminApi.getAvailabilityRules());
    } catch (err) {
      showError(err, "Unable to update availability rule");
    } finally {
      setBusy("");
    }
  };

  const deleteAvailabilityRule = async (rule) => {
    if (!window.confirm(`Delete availability rule for ${rule.service?.name || "this service"}?`)) return;
    setBusy(`availability:${rule.id}`);
    clearMessages();
    try {
      await adminApi.deleteAvailabilityRule(rule.id);
      setAvailabilityRules(await adminApi.getAvailabilityRules());
      setSuccess("Availability rule deleted.");
    } catch (err) {
      showError(err, "Unable to delete availability rule");
    } finally {
      setBusy("");
    }
  };

  const sortedPerformance = useMemo(() => [...performance].sort((a, b) => b.receivedRequests - a.receivedRequests), [performance]);

  return (
    <div className="space-y-5">
      <header className="rounded-2xl border border-line bg-white p-5 shadow-sm">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-sm font-bold uppercase tracking-wide text-muted"><FiShield /> Admin operations</div>
            <h1 className="mt-2 text-2xl font-extrabold text-ink">Control Center</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-muted">Handle escalations, customer booking support, garage risk controls, pricing coverage, imports, schedules, and service availability from one admin-only workspace.</p>
          </div>
          <button onClick={load} disabled={loading} className={`${buttonClass} border border-line bg-white text-ink hover:bg-bg-soft`}><FiRefreshCw className={loading ? "animate-spin" : ""} />Refresh all</button>
        </div>
        <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
          <StatCard label="Open escalations" value={overview.openEscalations} />
          <StatCard label="Restricted garages" value={overview.suspendedGarages} />
          <StatCard label="Active price schedules" value={overview.scheduledPrices} />
          <StatCard label="Availability rules" value={overview.activeAvailabilityRules} />
          <StatCard label="Admin actions (24h)" value={overview.recentAuditLogs} />
        </div>
      </header>

      {(error || success) && (
        <div className={`flex items-start gap-2 rounded-xl border px-4 py-3 text-sm ${error ? "border-red-200 bg-red-50 text-red-700" : "border-green-200 bg-green-50 text-green-700"}`}>
          {error ? <FiAlertCircle className="mt-0.5 shrink-0" /> : <FiCheck className="mt-0.5 shrink-0" />}
          <span>{error || success}</span>
          <button className="ml-auto" onClick={clearMessages}><FiX /></button>
        </div>
      )}

      <nav className="flex gap-2 overflow-x-auto rounded-2xl border border-line bg-white p-2 shadow-sm">
        {tabs.map(([value, label, Icon]) => (
          <button key={value} onClick={() => setTab(value)} className={`inline-flex h-10 shrink-0 items-center gap-2 rounded-xl px-4 text-sm font-bold ${tab === value ? "bg-ink text-white" : "text-muted hover:bg-bg-soft hover:text-ink"}`}>
            <Icon />{label}
          </button>
        ))}
      </nav>

      {loading ? (
        <div className="rounded-2xl border border-line bg-white p-12 text-center text-sm text-muted">Loading admin controls...</div>
      ) : (
        <>
          {tab === "escalations" && (
            <div className="space-y-5">
              <Section title="Action Required" description="Rules are evaluated whenever this page or the admin overview is loaded.">
                <div className="space-y-3">
                  {escalations.length === 0 && <p className="rounded-xl bg-bg-soft p-6 text-center text-sm text-muted">No active booking escalations.</p>}
                  {escalations.map((item) => (
                    <article key={item.id} className="rounded-xl border border-line p-4">
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <div className="flex flex-wrap items-center gap-2"><Badge value={item.severity} /><Badge value={item.status} /></div>
                          <h3 className="mt-2 font-extrabold text-ink">{item.title} · #{item.booking?.bookingCode}</h3>
                          <p className="mt-1 text-sm text-muted">{item.detail}</p>
                          <p className="mt-2 text-xs text-muted">{item.booking?.user?.name} · {item.booking?.user?.phone || item.booking?.user?.email || "No contact"} · {formatStatus(item.booking?.status)}</p>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          <button onClick={() => setSelectedBookingId(item.bookingId)} className={`${buttonClass} border border-line bg-white text-ink`}><FiEye />Open booking</button>
                          {item.status !== "ACKNOWLEDGED" && <button disabled={busy === `escalation:${item.id}`} onClick={() => updateEscalation(item, "ACKNOWLEDGED")} className={`${buttonClass} bg-amber-100 text-amber-900`}><FiClock />Acknowledge</button>}
                          {item.status !== "RESOLVED" && <button disabled={busy === `escalation:${item.id}`} onClick={() => updateEscalation(item, "RESOLVED")} className={`${buttonClass} bg-green-600 text-white`}><FiCheck />Resolve</button>}
                        </div>
                      </div>
                    </article>
                  ))}
                </div>
              </Section>

              <Section title="Escalation rules" description="Change how long the system waits before creating an admin alert.">
                <div className="grid gap-3 lg:grid-cols-2">
                  {escalationRules.map((rule) => (
                    <article key={rule.id} className="rounded-xl border border-line p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div><h3 className="font-bold text-ink">{rule.label}</h3><p className="mt-1 text-xs text-muted">{rule.key}</p></div>
                        <label className="flex items-center gap-2 text-sm font-semibold"><input type="checkbox" checked={rule.enabled} onChange={(event) => setEscalationRules((list) => list.map((item) => item.id === rule.id ? { ...item, enabled: event.target.checked } : item))} />Enabled</label>
                      </div>
                      <div className="mt-4 grid grid-cols-[1fr_1fr_auto] gap-2">
                        <input type="number" min="1" max="10080" value={rule.thresholdMinutes} onChange={(event) => setEscalationRules((list) => list.map((item) => item.id === rule.id ? { ...item, thresholdMinutes: event.target.value } : item))} className={fieldClass} />
                        <select value={rule.severity} onChange={(event) => setEscalationRules((list) => list.map((item) => item.id === rule.id ? { ...item, severity: event.target.value } : item))} className={fieldClass}><option>LOW</option><option>MEDIUM</option><option>HIGH</option><option>CRITICAL</option></select>
                        <button disabled={busy === `rule:${rule.id}`} onClick={() => saveEscalationRule(rule)} className={`${buttonClass} bg-ink text-white`}><FiSave /></button>
                      </div>
                    </article>
                  ))}
                </div>
              </Section>
            </div>
          )}

          {tab === "support" && (
            <Section title="Customer support booking panel" description="Search by booking code, customer name, email, phone, or vehicle registration.">
              <form onSubmit={searchBookings} className="flex flex-col gap-2 sm:flex-row">
                <div className="relative flex-1"><FiSearch className="absolute left-3 top-3 text-muted" /><input value={supportSearch} onChange={(event) => setSupportSearch(event.target.value)} placeholder="ROV booking code, phone, email, registration..." className={`${fieldClass} w-full pl-9`} /></div>
                <button disabled={busy === "support-search" || !supportSearch.trim()} className={`${buttonClass} bg-ink text-white`}><FiSearch />Search</button>
              </form>
              <div className="mt-5 space-y-3">
                {supportBookings.map((booking) => (
                  <article key={booking.id} className="rounded-xl border border-line p-4">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div>
                        <div className="flex flex-wrap items-center gap-2"><h3 className="font-extrabold text-ink">#{booking.bookingCode}</h3><Badge value={booking.status} />{booking.escalations?.length > 0 && <Badge value="HIGH" />}</div>
                        <p className="mt-2 text-sm text-muted">{booking.user?.name} · {booking.user?.phone || booking.user?.email} · {booking.vehicle?.brand} {booking.vehicle?.model}</p>
                        <p className="mt-1 text-xs text-muted">Garage: {booking.garage?.name || "Unassigned"} · Payment: {booking.payment?.status || "Not created"}</p>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        <button onClick={() => setSelectedBookingId(booking.id)} className={`${buttonClass} border border-line bg-white text-ink`}><FiEye />Manage</button>
                        <button disabled={busy.startsWith(`notify:${booking.id}`)} onClick={() => notifyBooking(booking.id, "CUSTOMER")} className={`${buttonClass} bg-blue-50 text-blue-700`}><FiBell />Customer</button>
                        <button disabled={!booking.garage || busy.startsWith(`notify:${booking.id}`)} onClick={() => notifyBooking(booking.id, "GARAGE")} className={`${buttonClass} bg-amber-50 text-amber-800`}><FiBell />Garage</button>
                      </div>
                    </div>
                  </article>
                ))}
                {supportSearch && supportBookings.length === 0 && busy !== "support-search" && <p className="rounded-xl bg-bg-soft p-6 text-center text-sm text-muted">No matching bookings.</p>}
              </div>
            </Section>
          )}

          {tab === "garages" && (
            <Section title="Garage performance scorecard" description="Operational status affects new booking discovery and acceptance, while existing bookings remain accessible." actions={<div className="flex gap-2"><select value={performanceDays} onChange={(event) => setPerformanceDays(Number(event.target.value))} className={fieldClass}><option value="7">7 days</option><option value="30">30 days</option><option value="90">90 days</option><option value="365">365 days</option></select><button onClick={refreshPerformance} className={`${buttonClass} border border-line bg-white text-ink`}><FiRefreshCw className={busy === "performance" ? "animate-spin" : ""} /></button></div>}>
              <div className="overflow-x-auto">
                <table className="min-w-[1250px] w-full text-left text-sm">
                  <thead><tr className="border-b border-line text-xs uppercase tracking-wide text-muted"><th className="px-2 py-3">Garage</th><th className="px-2">Status</th><th className="px-2">Requests</th><th className="px-2">Acceptance</th><th className="px-2">Completion</th><th className="px-2">Cancellation</th><th className="px-2">Response</th><th className="px-2">Rating</th><th className="px-2">Complaints</th><th className="px-2">Revenue</th><th className="px-2">Control</th></tr></thead>
                  <tbody>
                    {sortedPerformance.map((garage) => {
                      const draft = garageStatusDrafts[garage.id] || { status: garage.operationalStatus, reason: garage.suspensionReason || "", suspendedUntil: garage.suspendedUntil ? new Date(garage.suspendedUntil).toISOString().slice(0, 16) : "" };
                      return (
                        <tr key={garage.id} className="border-b border-line align-top">
                          <td className="px-2 py-3"><p className="font-bold text-ink">{garage.name}</p><p className="text-xs text-muted">{garage.city}</p></td>
                          <td className="px-2 py-3"><Badge value={garage.operationalStatus} /></td>
                          <td className="px-2 py-3">{garage.acceptedRequests}/{garage.receivedRequests}</td>
                          <td className="px-2 py-3 font-bold">{garage.acceptanceRate}%</td>
                          <td className="px-2 py-3">{garage.completedBookings}/{garage.assignedBookings} ({garage.completionRate}%)</td>
                          <td className="px-2 py-3">{garage.cancellationRate}%</td>
                          <td className="px-2 py-3">{garage.avgResponseMinutes} min</td>
                          <td className="px-2 py-3">{Number(garage.ratingAvg || 0).toFixed(1)} ({garage.ratingCount})</td>
                          <td className="px-2 py-3">{garage.complaintCount}</td>
                          <td className="px-2 py-3 font-bold">{formatRupees(garage.serviceRevenue)}</td>
                          <td className="px-2 py-3">
                            <div className="flex min-w-[640px] items-center gap-2">
                              <select value={draft.status} onChange={(event) => setGarageStatusDrafts((current) => ({ ...current, [garage.id]: { ...draft, status: event.target.value } }))} className={`${fieldClass} w-56 shrink-0`}>{availableOperationalStatuses.map((status) => <option key={status}>{status}</option>)}</select>
                              {draft.status === "TEMPORARILY_SUSPENDED" && <input type="datetime-local" value={draft.suspendedUntil} onChange={(event) => setGarageStatusDrafts((current) => ({ ...current, [garage.id]: { ...draft, suspendedUntil: event.target.value } }))} className={`${fieldClass} w-52 shrink-0`} />}
                              {draft.status !== "ACTIVE" && <input value={draft.reason} onChange={(event) => setGarageStatusDrafts((current) => ({ ...current, [garage.id]: { ...draft, reason: event.target.value } }))} placeholder="Reason" className={`${fieldClass} min-w-0 flex-1`} />}
                              <button disabled={busy === `garage:${garage.id}`} onClick={() => saveGarageStatus(garage)} className={`${buttonClass} bg-ink text-white`}><FiSave />Apply</button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </Section>
          )}

          {tab === "pricing" && (
            <div className="space-y-5">
              <Section title="Price-range coverage" description="See every untouched service and every missing city, brand, model, and fuel-type price scope." actions={<div className="flex flex-wrap gap-2"><button onClick={() => refreshCoverage()} disabled={busy === "coverage"} className={`${buttonClass} border border-line bg-white text-ink`}><FiRefreshCw className={busy === "coverage" ? "animate-spin" : ""} />Refresh</button><button onClick={exportCsv} disabled={busy === "export"} className={`${buttonClass} border border-line bg-white text-ink`}><FiDownload />Export CSV</button><label className={`${buttonClass} cursor-pointer bg-ink text-white`}><FiUpload />Choose CSV<input type="file" accept=".csv,text/csv" onChange={handleCsvFile} className="hidden" /></label></div>}>
                {coverage && (
                  <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                    <StatCard label="Active ranges" value={coverage.totals?.activeRanges} />
                    <StatCard label="Untouched services" value={coverage.totals?.untouchedServices} hint="No active price range of any type" />
                    <StatCard label="Brand + fuel gaps" value={coverage.totals?.brandFuelGaps} hint="At least one model is still missing" />
                    <StatCard label="Model + fuel gaps" value={coverage.totals?.modelFuelGaps} hint={`${coverage.totals?.coveredModelFuelScopes || 0} scopes already covered`} />
                  </div>
                )}
                {importPreview && <div className={`mt-4 rounded-xl border p-4 ${importPreview.valid ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}`}><p className="font-bold">CSV validation: {importPreview.valid ? "Ready" : "Errors found"}</p><p className="mt-1 text-sm">{importPreview.rows} rows checked.</p>{importPreview.errors?.slice(0, 12).map((item) => <p key={`${item.row}:${item.message}`} className="mt-1 text-sm text-red-700">Row {item.row}: {item.message}</p>)}{importPreview.valid && <button onClick={commitImport} disabled={busy === "import"} className={`${buttonClass} mt-3 bg-green-700 text-white`}><FiUpload />Import {importPreview.rows} rows</button>}</div>}
                <div className="mt-5 rounded-xl border border-line bg-bg-soft/60 p-4">
                  <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
                    <select value={coverageFilters.city} onChange={(event) => setCoverageFilters((current) => ({ ...current, city: event.target.value }))} className={fieldClass}><option value="">All cities</option>{coverage?.filters?.cities?.map((city) => <option key={city} value={city}>{city}</option>)}</select>
                    <select value={coverageFilters.serviceId} onChange={(event) => setCoverageFilters((current) => ({ ...current, serviceId: event.target.value }))} className={fieldClass}><option value="">All services</option>{coverage?.filters?.services?.map((service) => <option key={service.id} value={service.id}>{service.category} · {service.name}</option>)}</select>
                    <select value={coverageFilters.vehicleBrand} onChange={(event) => setCoverageFilters((current) => ({ ...current, vehicleBrand: event.target.value }))} className={fieldClass}><option value="">All brands</option>{coverage?.filters?.brands?.map((brand) => <option key={brand} value={brand}>{brand}</option>)}</select>
                    <select value={coverageFilters.fuelType} onChange={(event) => setCoverageFilters((current) => ({ ...current, fuelType: event.target.value }))} className={fieldClass}><option value="">All fuel types</option>{coverage?.filters?.fuelTypes?.map((fuel) => <option key={fuel} value={fuel}>{formatStatus(fuel)}</option>)}</select>
                  </div>
                  <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
                    <p className="text-xs leading-5 text-muted">Coverage recognises ALL-brand, ALL-model, and any-fuel ranges. Registered vehicle fuel combinations are used where available; models without usage data are checked against all supported fuels.</p>
                    <div className="flex gap-2"><button type="button" onClick={resetCoverageFilters} disabled={busy === "coverage"} className={`${buttonClass} border border-line bg-white text-ink`}>Clear</button><button type="button" onClick={() => refreshCoverage()} disabled={busy === "coverage"} className={`${buttonClass} bg-ink text-white`}><FiSearch />Apply filters</button></div>
                  </div>
                </div>

                <div className="mt-5 rounded-xl border border-line bg-white p-4">
                  <div className="flex flex-wrap items-end justify-between gap-2"><div><h3 className="font-extrabold text-ink">Untouched services</h3><p className="mt-1 text-xs text-muted">These services have no active price range in any city, brand, model, or fuel type.</p></div><span className="text-sm font-bold text-muted">{coverage?.untouchedServices?.length || 0}</span></div>
                  <div className="mt-3 grid gap-2 md:grid-cols-2 xl:grid-cols-3">
                    {coverage?.untouchedServices?.map((item) => <article key={item.id} className="border border-line bg-bg-soft px-3 py-3"><p className="text-xs font-bold uppercase tracking-wide text-muted">{item.category}</p><p className="mt-1 text-sm font-extrabold text-ink">{item.name}</p></article>)}
                    {coverage?.untouchedServices?.length === 0 && <p className="text-sm text-emerald-700">Every active service has at least one price range.</p>}
                  </div>
                </div>

                <div className="mt-5 grid gap-5 xl:grid-cols-2">
                  <div className="overflow-hidden rounded-xl border border-line bg-white">
                    <div className="border-b border-line px-4 py-3"><h3 className="font-extrabold text-ink">Remaining brand and fuel coverage</h3><p className="mt-1 text-xs text-muted">Shows how many models still need pricing for each brand and fuel type.</p></div>
                    <div className="max-h-[430px] overflow-auto"><table className="min-w-[760px] w-full text-left text-sm"><thead className="sticky top-0 bg-bg-soft text-xs uppercase tracking-wide text-muted"><tr><th className="px-3 py-3">City</th><th className="px-3">Service</th><th className="px-3">Brand</th><th className="px-3">Fuel</th><th className="px-3">Missing</th></tr></thead><tbody>{coverage?.brandFuelGaps?.map((item) => <tr key={`${item.city}:${item.serviceId}:${item.vehicleBrand}:${item.fuelType}`} className="border-t border-line"><td className="px-3 py-3">{item.city}</td><td className="px-3 py-3"><p className="font-bold text-ink">{item.serviceName}</p><p className="text-xs text-muted">{item.category}</p></td><td className="px-3 py-3 font-semibold">{item.vehicleBrand}</td><td className="px-3 py-3">{formatStatus(item.fuelType)}</td><td className="px-3 py-3 font-bold text-red-700">{item.missingModels}/{item.totalModels} models</td></tr>)}</tbody></table>{coverage?.brandFuelGaps?.length === 0 && <p className="p-5 text-sm text-emerald-700">No brand and fuel gaps match these filters.</p>}</div>
                    {coverage?.resultMeta?.brandResultsTruncated && <p className="border-t border-line px-4 py-3 text-xs text-amber-800">Showing the first {coverage.resultMeta.returnedBrandFuelGaps} of {coverage.resultMeta.filteredBrandFuelGapCount} matching gaps. Narrow the filters to see the rest.</p>}
                  </div>

                  <div className="overflow-hidden rounded-xl border border-line bg-white">
                    <div className="border-b border-line px-4 py-3"><h3 className="font-extrabold text-ink">Remaining model and fuel coverage</h3><p className="mt-1 text-xs text-muted">Exact vehicle model and fuel combinations that still have no usable price.</p></div>
                    <div className="max-h-[430px] overflow-auto"><table className="min-w-[820px] w-full text-left text-sm"><thead className="sticky top-0 bg-bg-soft text-xs uppercase tracking-wide text-muted"><tr><th className="px-3 py-3">City</th><th className="px-3">Service</th><th className="px-3">Brand</th><th className="px-3">Model</th><th className="px-3">Fuel</th></tr></thead><tbody>{coverage?.modelFuelGaps?.map((item) => <tr key={`${item.city}:${item.serviceId}:${item.vehicleBrand}:${item.vehicleModel}:${item.fuelType}`} className="border-t border-line"><td className="px-3 py-3">{item.city}</td><td className="px-3 py-3"><p className="font-bold text-ink">{item.serviceName}</p><p className="text-xs text-muted">{item.category}</p></td><td className="px-3 py-3 font-semibold">{item.vehicleBrand}</td><td className="px-3 py-3">{item.vehicleModel}</td><td className="px-3 py-3 font-bold text-red-700">{formatStatus(item.fuelType)}</td></tr>)}</tbody></table>{coverage?.modelFuelGaps?.length === 0 && <p className="p-5 text-sm text-emerald-700">No model and fuel gaps match these filters.</p>}</div>
                    {coverage?.resultMeta?.modelResultsTruncated && <p className="border-t border-line px-4 py-3 text-xs text-amber-800">Showing the first {coverage.resultMeta.returnedModelFuelGaps} of {coverage.resultMeta.filteredModelFuelGapCount} matching gaps. Narrow the filters to see the rest.</p>}
                  </div>
                </div>
              </Section>

              <Section title="Scheduled pricing" description="Apply a price automatically and optionally restore the previous price after the end date.">
                <form onSubmit={createSchedule} className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
                  <select required value={scheduleForm.city} onChange={(event) => setScheduleForm({ ...scheduleForm, city: event.target.value })} className={fieldClass}><option value="">Select city</option>{cities.filter((city) => city.isActive).map((city) => <option key={city.id} value={city.name}>{city.name}</option>)}</select>
                  <select required value={scheduleForm.serviceId} onChange={(event) => setScheduleForm({ ...scheduleForm, serviceId: event.target.value })} className={fieldClass}><option value="">Select service</option>{services.map((service) => <option key={service.id} value={service.id}>{service.category?.name} · {service.name}</option>)}</select>
                  <input required value={scheduleForm.vehicleBrand} onChange={(event) => setScheduleForm({ ...scheduleForm, vehicleBrand: event.target.value })} placeholder="Vehicle brand or ALL" className={fieldClass} />
                  <input value={scheduleForm.vehicleModel} onChange={(event) => setScheduleForm({ ...scheduleForm, vehicleModel: event.target.value })} placeholder="Vehicle model or ALL" className={fieldClass} />
                  <select value={scheduleForm.fuelType} onChange={(event) => setScheduleForm({ ...scheduleForm, fuelType: event.target.value })} className={fieldClass}>{fuelTypes.map((fuel) => <option key={fuel} value={fuel}>{fuel || "Any fuel"}</option>)}</select>
                  <input required type="number" min="0" value={scheduleForm.minPrice} onChange={(event) => setScheduleForm({ ...scheduleForm, minPrice: event.target.value })} placeholder="Minimum price" className={fieldClass} />
                  <input required type="number" min="0" value={scheduleForm.maxPrice} onChange={(event) => setScheduleForm({ ...scheduleForm, maxPrice: event.target.value })} placeholder="Maximum price" className={fieldClass} />
                  <input required type="datetime-local" value={scheduleForm.startsAt} onChange={(event) => setScheduleForm({ ...scheduleForm, startsAt: event.target.value })} className={fieldClass} />
                  <input type="datetime-local" value={scheduleForm.endsAt} onChange={(event) => setScheduleForm({ ...scheduleForm, endsAt: event.target.value })} className={fieldClass} />
                  <button disabled={busy === "schedule-create"} className={`${buttonClass} bg-ink text-white xl:col-span-2`}><FiClock />Create schedule</button>
                </form>
                <div className="mt-5 overflow-x-auto"><table className="min-w-[900px] w-full text-left text-sm"><thead><tr className="border-b border-line text-xs uppercase text-muted"><th className="py-3">Service</th><th>Scope</th><th>Price</th><th>Starts</th><th>Ends</th><th>Status</th><th></th></tr></thead><tbody>{schedules.map((item) => <tr key={item.id} className="border-b border-line"><td className="py-3 font-bold">{item.service?.name}</td><td>{item.city} · {item.vehicleBrand || "ALL"} {item.vehicleModel ? `· ${item.vehicleModel}` : ""}</td><td>{formatRupees(item.minPrice)}–{formatRupees(item.maxPrice)}</td><td>{formatDateTime(item.startsAt)}</td><td>{formatDateTime(item.endsAt)}</td><td><Badge value={item.status} /></td><td>{!["CANCELLED", "EXPIRED"].includes(item.status) && <button disabled={busy === `schedule:${item.id}`} onClick={() => cancelSchedule(item.id)} className="text-sm font-bold text-red-600">Cancel</button>}</td></tr>)}</tbody></table></div>
              </Section>
            </div>
          )}

          {tab === "availability" && (
            <div className="space-y-5">
              <Section title="Create service availability rule" description="Use ALLOW rules to restrict a service to matching scopes, or DENY rules to block matching scopes.">
                <form onSubmit={createAvailabilityRule} className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
                  <select required value={ruleForm.serviceId} onChange={(event) => setRuleForm({ ...ruleForm, serviceId: event.target.value })} className={fieldClass}><option value="">Select service</option>{services.map((service) => <option key={service.id} value={service.id}>{service.category?.name} · {service.name}</option>)}</select>
                  <select value={ruleForm.cityId} onChange={(event) => setRuleForm({ ...ruleForm, cityId: event.target.value })} className={fieldClass}><option value="">All cities</option>{cities.map((city) => <option key={city.id} value={city.id}>{city.name}</option>)}</select>
                  <select value={ruleForm.garageId} onChange={(event) => setRuleForm({ ...ruleForm, garageId: event.target.value })} className={fieldClass}><option value="">All garages</option>{garages.map((garage) => <option key={garage.id} value={garage.id}>{garage.name} · {garage.city}</option>)}</select>
                  <select value={ruleForm.effect} onChange={(event) => setRuleForm({ ...ruleForm, effect: event.target.value })} className={fieldClass}><option value="DENY">DENY matching scope</option><option value="ALLOW">ALLOW only matching scope</option></select>
                  <input value={ruleForm.vehicleBrand} onChange={(event) => setRuleForm({ ...ruleForm, vehicleBrand: event.target.value })} placeholder="Vehicle brand (optional)" className={fieldClass} />
                  <input value={ruleForm.vehicleModel} onChange={(event) => setRuleForm({ ...ruleForm, vehicleModel: event.target.value })} placeholder="Vehicle model (optional)" className={fieldClass} />
                  <select value={ruleForm.fuelType} onChange={(event) => setRuleForm({ ...ruleForm, fuelType: event.target.value })} className={fieldClass}>{fuelTypes.map((fuel) => <option key={fuel} value={fuel}>{fuel || "Any fuel"}</option>)}</select>
                  <select value={ruleForm.dayOfWeek} onChange={(event) => setRuleForm({ ...ruleForm, dayOfWeek: event.target.value })} className={fieldClass}><option value="">Every day</option>{days.map((day, index) => <option key={day} value={index}>{day}</option>)}</select>
                  <input type="time" value={ruleForm.startTime} onChange={(event) => setRuleForm({ ...ruleForm, startTime: event.target.value })} className={fieldClass} />
                  <input type="time" value={ruleForm.endTime} onChange={(event) => setRuleForm({ ...ruleForm, endTime: event.target.value })} className={fieldClass} />
                  <input value={ruleForm.reason} onChange={(event) => setRuleForm({ ...ruleForm, reason: event.target.value })} placeholder="Customer-facing reason/internal context" className={`${fieldClass} xl:col-span-2`} />
                  <button disabled={busy === "availability-create"} className={`${buttonClass} bg-ink text-white xl:col-span-2`}><FiSave />Create rule</button>
                </form>
              </Section>
              <Section title="Configured availability rules" description="Inactive rules remain stored but are not enforced.">
                <div className="space-y-3">{availabilityRules.map((rule) => <article key={rule.id} className="rounded-xl border border-line p-4"><div className="flex flex-wrap items-start justify-between gap-3"><div><div className="flex gap-2"><Badge value={rule.effect} /><Badge value={rule.isActive ? "ACTIVE" : "CANCELLED"} /></div><h3 className="mt-2 font-bold text-ink">{rule.service?.category?.name} · {rule.service?.name}</h3><p className="mt-1 text-sm text-muted">{rule.city?.name || "All cities"} · {rule.garage?.name || "All garages"} · {rule.vehicleBrand || "Any brand"} · {rule.vehicleModel || "Any model"} · {rule.fuelType || "Any fuel"}</p><p className="mt-1 text-xs text-muted">{rule.dayOfWeek === null ? "Every day" : days[rule.dayOfWeek]} {rule.startTime || rule.endTime ? `· ${rule.startTime || "00:00"}–${rule.endTime || "23:59"}` : ""} {rule.reason ? `· ${rule.reason}` : ""}</p></div><div className="flex gap-2"><button disabled={busy === `availability:${rule.id}`} onClick={() => toggleAvailabilityRule(rule)} className={`${buttonClass} border border-line bg-white text-ink`}>{rule.isActive ? <FiSlash /> : <FiCheck />}{rule.isActive ? "Disable" : "Enable"}</button><button disabled={busy === `availability:${rule.id}`} onClick={() => deleteAvailabilityRule(rule)} className={`${buttonClass} bg-red-50 text-red-700`}><FiTrash2 /></button></div></div></article>)}</div>
              </Section>
            </div>
          )}

          {tab === "audit" && (
            <Section
              title="Admin audit logs"
              description="Every action is tied to the exact Main Admin, Admin, or intern account that performed it. Email and login ID are stored as point-in-time audit snapshots."
            >
              <div className="mb-5 rounded-xl border border-line bg-bg-soft/60 p-3">
                <div className="grid gap-3 md:grid-cols-[minmax(0,1fr)_220px_auto] md:items-center">
                  <label className="relative block min-w-0">
                    <FiSearch className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
                    <input
                      value={auditSearch}
                      onChange={(event) => setAuditSearch(event.target.value)}
                      placeholder="Search name, email, login ID, action or route"
                      className={`${fieldClass} w-full bg-white pl-10`}
                    />
                  </label>

                  <select
                    value={auditRole}
                    onChange={(event) => setAuditRole(event.target.value)}
                    className={`${fieldClass} w-full bg-white`}
                  >
                    <option value="">All staff accounts</option>
                    <option value="ADMIN">Main admins</option>
                    <option value="SUB_ADMIN">Admins</option>
                    <option value="INTERN">Interns</option>
                  </select>

                  <div className="flex h-10 items-center justify-center rounded-lg border border-line bg-white px-3 text-xs font-extrabold text-ink">
                    {filteredAuditLogs.length} log{filteredAuditLogs.length === 1 ? "" : "s"}
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                {filteredAuditLogs.map((log) => {
                  const roleLabel = log.actorRole === "ADMIN"
                    ? "MAIN ADMIN"
                    : log.actorRole === "SUB_ADMIN"
                      ? "ADMIN"
                      : log.actorRole || "UNKNOWN ROLE";
                  const primaryIdentifier = log.actorEmail || log.actorLoginId || log.actorId || "Identifier unavailable";
                  const numericStatus = Number(log.statusCode);
                  const hasStatusCode = Number.isFinite(numericStatus);
                  const requestSucceeded = hasStatusCode && numericStatus < 400;

                  return (
                    <article
                      key={log.id}
                      className="overflow-hidden rounded-xl border border-line bg-white transition hover:border-gray-300 hover:shadow-[0_8px_24px_rgba(15,23,42,0.05)]"
                    >
                      <header className="flex flex-col gap-3 border-b border-line bg-bg-soft/45 px-4 py-3.5 sm:flex-row sm:items-center sm:justify-between sm:px-5">
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <h3 className="truncate text-sm font-extrabold text-ink sm:text-base">
                              {log.actorName || "Unknown staff account"}
                            </h3>
                            <span className="rounded-full border border-line bg-white px-2 py-0.5 text-[10px] font-extrabold text-ink">
                              {roleLabel}
                            </span>
                          </div>
                          <p className="mt-1 min-w-0 break-words text-xs font-semibold text-muted [overflow-wrap:anywhere]">
                            {primaryIdentifier}
                          </p>
                        </div>

                        <div className="flex shrink-0 items-center gap-3 sm:text-right">
                          <div>
                            <p className="text-xs font-bold text-ink">
                              {formatDateTime(log.createdAt)}
                            </p>
                            <p className="mt-0.5 text-[10px] font-semibold uppercase tracking-wide text-muted">
                              Audit timestamp
                            </p>
                          </div>
                          <span
                            className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-extrabold ${
                              !hasStatusCode
                                ? "border-line bg-white text-muted"
                                : requestSucceeded
                                  ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                                  : "border-red-200 bg-red-50 text-red-700"
                            }`}
                          >
                            <span
                              className={`h-1.5 w-1.5 rounded-full ${
                                !hasStatusCode
                                  ? "bg-gray-400"
                                  : requestSucceeded
                                    ? "bg-emerald-500"
                                    : "bg-red-500"
                              }`}
                            />
                            {hasStatusCode
                              ? `${requestSucceeded ? "Success" : "Failed"} · ${log.statusCode}`
                              : "No status"}
                          </span>
                        </div>
                      </header>

                      <div className="grid gap-4 px-4 py-4 sm:px-5 lg:grid-cols-[minmax(0,0.82fr)_minmax(0,1.18fr)]">
                        <div className="min-w-0 rounded-lg border border-line bg-white p-3.5">
                          <p className="text-[10px] font-extrabold uppercase tracking-[0.13em] text-muted">
                            Activity
                          </p>
                          <div className="mt-2 flex flex-wrap items-center gap-2">
                            <Badge value={log.action} />
                            <span className="min-w-0 break-words text-sm font-bold text-ink [overflow-wrap:anywhere]">
                              {log.resource || "Unknown resource"}
                            </span>
                          </div>
                          {log.resourceId && (
                            <p className="mt-2 break-words font-mono text-[11px] text-muted [overflow-wrap:anywhere]">
                              Resource ID: {log.resourceId}
                            </p>
                          )}
                        </div>

                        <div className="min-w-0 rounded-lg border border-line bg-gray-950 p-3.5 text-white">
                          <p className="text-[10px] font-extrabold uppercase tracking-[0.13em] text-white/55">
                            Request route
                          </p>
                          <div className="mt-2 flex min-w-0 items-start gap-2.5">
                            <span className="shrink-0 rounded-md bg-white/10 px-2 py-1 text-[10px] font-black text-[#b9f000]">
                              {log.method || "-"}
                            </span>
                            <code className="min-w-0 break-words text-xs leading-5 text-white/90 [overflow-wrap:anywhere]" title={log.path}>
                              {log.path || "Route unavailable"}
                            </code>
                          </div>
                        </div>
                      </div>

                      <footer className="flex flex-col gap-1.5 border-t border-line px-4 py-3 text-[11px] text-muted sm:flex-row sm:flex-wrap sm:items-center sm:gap-x-5 sm:px-5">
                        {log.actorEmail && log.actorLoginId && log.actorEmail !== log.actorLoginId && (
                          <span className="break-words [overflow-wrap:anywhere]">
                            <strong className="font-bold text-gray-700">Login ID:</strong>{" "}
                            {log.actorLoginId}
                          </span>
                        )}
                        {log.actorId && (
                          <span className="break-words font-mono [overflow-wrap:anywhere]">
                            Account ID: {log.actorId}
                          </span>
                        )}
                        <span className="break-words [overflow-wrap:anywhere] sm:ml-auto">
                          IP: {log.ipAddress || "Unavailable"}
                        </span>
                      </footer>
                    </article>
                  );
                })}

                {filteredAuditLogs.length === 0 && (
                  <div className="rounded-xl border border-dashed border-line bg-white px-4 py-14 text-center sm:px-6">
                    <div className="mx-auto grid h-11 w-11 place-items-center rounded-full bg-bg-soft text-muted">
                      <FiFileText />
                    </div>
                    <p className="mt-3 text-sm font-bold text-ink">
                      No matching audit logs
                    </p>
                    <p className="mt-1 text-xs text-muted">
                      Try changing the search term or staff filter.
                    </p>
                  </div>
                )}
              </div>
            </Section>
          )}
        </>
      )}

      {selectedBookingId && <BookingManagementModal bookingId={selectedBookingId} isAdmin onClose={() => setSelectedBookingId("")} onUpdated={() => { searchBookings(); load(); }} />}
    </div>
  );
}
