import { useEffect, useState } from "react";
import {
  FiCalendar,
  FiChevronDown,
  FiClock,
  FiDownload,
  FiEdit3,
  FiRefreshCw,
  FiStar,
  FiTool,
} from "react-icons/fi";
import ReviewModal from "@/components/reviews/ReviewModal";
import { useApp } from "@/hooks/useApp";
import { downloadServiceHistoryPdf } from "@/utils/serviceHistoryPdf";
import { isSelfDropOffService } from "@/utils/serviceFulfillment";

const formatDate = (date) => {
  if (!date) return "-";

  return new Date(date).toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

const formatDateTime = (date) => {
  if (!date) return "Not recorded";

  return new Date(date).toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
};

const formatDuration = (start, end) => {
  const startTime = start ? new Date(start).getTime() : NaN;
  const endTime = end ? new Date(end).getTime() : NaN;
  if (!Number.isFinite(startTime) || !Number.isFinite(endTime)) {
    return "Not recorded";
  }

  const totalMinutes = Math.max(0, Math.round((endTime - startTime) / 60000));
  const days = Math.floor(totalMinutes / 1440);
  const hours = Math.floor((totalMinutes % 1440) / 60);
  const minutes = totalMinutes % 60;

  return [
    days ? `${days}d` : "",
    hours ? `${hours}h` : "",
    `${minutes}m`,
  ]
    .filter(Boolean)
    .join(" ");
};

const getTimingDetails = (booking) => {
  const selfDropOff = isSelfDropOffService(booking);
  const timings = selfDropOff
    ? [
        {
          label: "Home to garage",
          start: booking.acceptedAt,
          end: booking.arrivedAtGarageAt,
        },
        {
          label: "Service work",
          start: booking.arrivedAtGarageAt,
          end: booking.serviceCompletedAt,
        },
      ]
    : [
        {
          label: "Garage to customer",
          start: booking.acceptedAt,
          end: booking.handoverOtpVerifiedAt,
        },
        {
          label: "Return to garage",
          start: booking.handoverOtpVerifiedAt,
          end: booking.arrivedAtGarageAt,
        },
        {
          label: "Service work",
          start: booking.arrivedAtGarageAt,
          end: booking.serviceCompletedAt,
        },
        {
          label: "Delivery to customer",
          start: booking.serviceCompletedAt,
          end: booking.deliveredAt,
        },
      ];

  timings.push(
    {
      label: "Payment confirmation",
      start: booking.finalPaymentSubmittedAt,
      end: booking.finalPaymentConfirmedAt,
    },
    {
      label: "Total booking time",
      start: booking.acceptedAt,
      end: booking.finalPaymentConfirmedAt || booking.customerAcceptedAt,
    },
  );

  return timings;
};

const getServicesText = (booking) =>
  booking.services
    ?.map((item) => item.service?.name)
    .filter(Boolean)
    .join(", ") || "Vehicle Service";

const getGarageText = (booking) =>
  booking.garage?.name || "Auto-assigned garage";

const getVehicleText = (booking) => {
  const vehicle = booking.vehicle;

  if (!vehicle) return "Saved vehicle";

  return (
    `${vehicle.brand || ""} ${vehicle.model || ""}`.trim() ||
    vehicle.registrationNumber ||
    "Saved vehicle"
  );
};

const getAmountText = (booking) => {
  const amount = Number(
    booking.finalPaymentAmount || booking.totalServiceAmount || 0,
  );

  return amount > 0 ? `₹${amount.toLocaleString("en-IN")}` : "Not recorded";
};

function RatingDisplay({ review }) {
  if (!review) {
    return <span className="text-sm font-semibold text-muted">Not rated</span>;
  }

  return (
    <span className="inline-flex items-center gap-1 text-sm font-bold text-ink">
      <FiStar className="text-amber-500" fill="currentColor" />
      {Number(review.rating || 0).toFixed(1)} / 5
    </span>
  );
}

export default function ServiceHistory() {
  const {
    fetchServiceHistory,
    clearBookingCaches,
    serviceHistoryCache,
  } = useApp();

  const [history, setHistory] = useState(() =>
    Array.isArray(serviceHistoryCache) ? serviceHistoryCache : [],
  );
  const [loading, setLoading] = useState(
    () => !Array.isArray(serviceHistoryCache),
  );
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [reviewBooking, setReviewBooking] = useState(null);

  const loadHistory = async ({ force = false } = {}) => {
    try {
      if (force) setRefreshing(true);
      else if (!Array.isArray(serviceHistoryCache)) setLoading(true);

      setError("");
      const data = await fetchServiceHistory({ force });
      setHistory(data || []);
    } catch (err) {
      setError(err.response?.data?.message || "Failed to load service history");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadHistory();
  }, []);

  const handleReviewSaved = (savedReview) => {
    setHistory((current) =>
      current.map((booking) =>
        booking.id === savedReview.bookingId
          ? { ...booking, review: savedReview }
          : booking,
      ),
    );
    setReviewBooking((current) =>
      current?.id === savedReview.bookingId
        ? { ...current, review: savedReview }
        : current,
    );
    clearBookingCaches?.();
    setSuccess(
      reviewBooking?.review
        ? "Review updated successfully."
        : "Review submitted successfully.",
    );
  };

  if (loading) {
    return (
      <div>
        <h2 className="mb-6 text-2xl font-bold">Service History</h2>
        <div className="rounded-lg border border-line bg-white p-5 text-sm text-muted shadow-sm">
          Loading service history...
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6 flex items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold sm:text-3xl">Service History</h2>
          <p className="mt-1 text-sm text-muted">
            Completed bookings with downloadable detailed reports.
          </p>
        </div>

        <button
          type="button"
          disabled={refreshing}
          onClick={() => loadHistory({ force: true })}
          className="inline-flex h-9 items-center justify-center gap-2 rounded-md border border-line bg-white px-3.5 text-sm font-medium text-ink shadow-sm transition hover:border-ink/25 hover:bg-bg-soft disabled:cursor-not-allowed disabled:opacity-50"
        >
          <FiRefreshCw className={refreshing ? "animate-spin" : ""} />
          <span className="hidden sm:inline">
            {refreshing ? "Refreshing..." : "Refresh"}
          </span>
        </button>
      </div>

      {error && (
        <div className="mb-4 rounded-md border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-600">
          {error}
        </div>
      )}

      {success && (
        <div className="mb-4 rounded-md border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-700">
          {success}
        </div>
      )}

      <div className="space-y-3">
        {history.map((booking) => {
          const completedDate = formatDate(
            booking.finalPaymentConfirmedAt ||
              booking.customerAcceptedAt ||
              booking.updatedAt ||
              booking.createdAt,
          );
          const timingDetails = getTimingDetails(booking);
          const selfDropOff = isSelfDropOffService(booking);
          const totalTiming = timingDetails[timingDetails.length - 1];

          return (
            <article
              key={booking.id}
              className="overflow-hidden rounded-xl border border-line bg-white shadow-sm transition hover:border-ink/15 hover:shadow-md"
            >
              <div className="p-4 sm:p-5">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate text-[11px] font-bold uppercase tracking-[0.08em] text-muted">
                      Booking #{booking.bookingCode || booking.id}
                    </p>
                    <h3 className="mt-1 line-clamp-2 text-lg font-bold leading-snug text-ink">
                      {getServicesText(booking)}
                    </h3>
                    <p className="mt-1 line-clamp-1 text-sm text-muted">
                      {getVehicleText(booking)} · {getGarageText(booking)}
                    </p>
                  </div>

                  <div className="shrink-0 rounded-lg border border-green-200 bg-green-50 px-3 py-2 text-center">
                    <p className="text-[10px] font-bold uppercase tracking-wide text-green-700">
                      Status
                    </p>
                    <p className="mt-0.5 text-xs font-black text-green-800">
                      Completed
                    </p>
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-2 lg:grid-cols-4">
                  <div className="rounded-lg border border-line bg-bg-soft/60 p-3">
                    <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-muted">
                      <FiCalendar /> Completed
                    </p>
                    <p className="mt-1 text-sm font-bold text-ink">
                      {completedDate}
                    </p>
                  </div>

                  <div className="rounded-lg border border-line bg-bg-soft/60 p-3">
                    <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-muted">
                      <FiClock /> Total time
                    </p>
                    <p className="mt-1 text-sm font-bold text-ink">
                      {formatDuration(totalTiming.start, totalTiming.end)}
                    </p>
                  </div>

                  <div className="rounded-lg border border-line bg-bg-soft/60 p-3">
                    <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-muted">
                      <FiTool /> Final amount
                    </p>
                    <p className="mt-1 text-sm font-bold text-ink">
                      {getAmountText(booking)}
                    </p>
                  </div>

                  <div className="rounded-lg border border-line bg-bg-soft/60 p-3">
                    <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-muted">
                      <FiStar /> Rating
                    </p>
                    <div className="mt-1">
                      <RatingDisplay review={booking.review} />
                    </div>
                  </div>
                </div>

                <details className="group mt-4 rounded-lg border border-line bg-white">
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-3 px-3.5 py-3 text-sm font-semibold text-ink marker:hidden">
                    <span className="inline-flex items-center gap-2">
                      <FiClock className="text-muted" /> Detailed service timing
                      <span className="text-xs font-medium text-muted">
                        · {selfDropOff ? "Self drop-off" : "Pickup and delivery"}
                      </span>
                    </span>
                    <FiChevronDown className="shrink-0 transition group-open:rotate-180" />
                  </summary>

                  <div className="grid gap-px border-t border-line bg-line sm:grid-cols-2 xl:grid-cols-3">
                    {timingDetails.map((item) => (
                      <div key={item.label} className="min-w-0 bg-white p-3">
                        <p className="text-[11px] font-bold uppercase tracking-wide text-muted">
                          {item.label}
                        </p>
                        <p className="mt-1 text-sm font-bold text-ink">
                          {formatDuration(item.start, item.end)}
                        </p>
                        <p className="mt-1 break-words text-[11px] leading-4 text-muted">
                          {formatDateTime(item.start)}
                          {item.end ? ` → ${formatDateTime(item.end)}` : ""}
                        </p>
                      </div>
                    ))}
                  </div>
                </details>
              </div>

              <div className="flex flex-col gap-2 border-t border-line bg-bg-soft/40 p-3 sm:flex-row sm:justify-end">
                <button
                  type="button"
                  onClick={() => downloadServiceHistoryPdf(booking)}
                  className="inline-flex h-10 items-center justify-center gap-2 rounded-lg border border-ink bg-white px-4 text-sm font-bold text-ink transition hover:bg-ink hover:text-white"
                >
                  <FiDownload /> Download detailed PDF
                </button>

                <button
                  type="button"
                  className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-brand px-4 text-sm font-bold text-black shadow-sm transition hover:bg-brand-dark"
                  onClick={() => {
                    setSuccess("");
                    setReviewBooking(booking);
                  }}
                >
                  {booking.review ? <FiEdit3 /> : <FiStar />}
                  {booking.review ? "Edit Review" : "Rate Garage"}
                </button>
              </div>
            </article>
          );
        })}

        {history.length === 0 && (
          <div className="rounded-lg border border-dashed border-line bg-white p-8 text-center text-sm text-muted shadow-sm">
            No completed services yet.
          </div>
        )}
      </div>

      <ReviewModal
        open={Boolean(reviewBooking)}
        booking={reviewBooking}
        review={reviewBooking?.review}
        onClose={() => setReviewBooking(null)}
        onSaved={handleReviewSaved}
      />
    </div>
  );
}
