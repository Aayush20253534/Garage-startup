import {
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";
import { useDispatch, useSelector } from "react-redux";
import { FiAlertCircle, FiRefreshCw } from "react-icons/fi";
import { useNavigate } from "react-router-dom";
import BookingCard from "@/components/garage/BookingCard";
import { setBookings } from "@/store/garageSlice";
import { garageApi } from "@/api/garage";
import { useApp } from "@/hooks/useApp";

const statusFilters = [
  "All",
  "New",
  "Accepted",
  "Confirmed",
  "In Progress",
  "Delivered",
  "Completed",
  "Rejected",
  "Expired",
];

const toStatus = (filter) => {
  if (filter === "All") return "";
  if (filter === "New") return "SENT";
  return filter.replaceAll(" ", "_").toUpperCase();
};

export default function GarageBookings() {
  const { bookings, wallet } = useSelector((state) => state.garage);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { garage } = useApp();

  const [activeFilter, setActiveFilter] = useState("All");
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");
  const requestInFlight = useRef(false);

  const safeBookings = Array.isArray(bookings) ? bookings : [];
  const walletBalance = Number(
    wallet?.balance ?? garage?.walletBalance ?? garage?.wallet?.balance ?? NaN,
  );

  const loadBookings = useCallback(
    async ({ initial = false } = {}) => {
      if (!garage || requestInFlight.current) return;

      requestInFlight.current = true;
      if (initial) setLoading(true);
      else setRefreshing(true);

      try {
        const data = await garageApi.getRequests(toStatus(activeFilter));

        dispatch(setBookings(Array.isArray(data) ? data : []));
        setError("");
      } catch (err) {
        setError(
          err.response?.data?.message || "Unable to load bookings",
        );
      } finally {
        requestInFlight.current = false;
        setLoading(false);
        setRefreshing(false);
      }
    },
    [activeFilter, dispatch, garage],
  );

  useEffect(() => {
    loadBookings({ initial: true });
  }, [loadBookings]);

  // Avoid constant polling from the garage bookings page. Bookings now load
  // once on page/filter change, then refresh only when the garage clicks Refresh
  // or after a booking action such as accept/decline.

  const handleAccept = async (booking) => {
    try {
      setError("");

      const updated = await garageApi.acceptRequest(
        booking.requestId || booking.id,
      );

      dispatch(
        setBookings(
          safeBookings.map((item) =>
            item.id === booking.id ? updated : item,
          ),
        ),
      );

      navigate(`/garage/bookings/${updated.requestId || updated.id}`);
    } catch (err) {
      setError(
        err.response?.data?.message || "Unable to accept booking",
      );
    }
  };

  const handleDecline = async (booking) => {
    try {
      setError("");

      const updated = await garageApi.rejectRequest(
        booking.requestId || booking.id,
      );

      dispatch(
        setBookings(
          safeBookings.map((item) =>
            item.id === booking.id ? updated : item,
          ),
        ),
      );

      await loadBookings();
    } catch (err) {
      setError(
        err.response?.data?.message || "Unable to decline booking",
      );
    }
  };

  return (
    <div className="mx-auto max-w-6xl space-y-5 overflow-x-hidden">
      <div className="flex flex-col gap-3 border-b border-line pb-5 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-ink sm:text-3xl">
            Bookings
          </h1>
          <p className="mt-1 text-sm text-muted">
            Bookings load once per page visit. Use Refresh to check for new requests.
          </p>
        </div>

        <button
          type="button"
          onClick={() => loadBookings()}
          disabled={loading || refreshing}
          className="inline-flex h-9 w-fit self-start items-center justify-center gap-2 rounded-md border border-line bg-white px-3.5 text-sm font-medium text-ink shadow-sm transition hover:border-ink/25 hover:bg-bg-soft disabled:cursor-not-allowed disabled:opacity-60 sm:self-auto"
        >
          <FiRefreshCw
            className={loading || refreshing ? "animate-spin" : ""}
          />
          Refresh
        </button>
      </div>

      <section className="rounded-lg border border-line bg-white p-2 shadow-sm">
        <div className="flex gap-2 overflow-x-auto pb-1">
          {statusFilters.map((filter) => (
            <button
              key={filter}
              type="button"
              onClick={() => setActiveFilter(filter)}
              className={[
                "h-8 shrink-0 rounded-md px-3 text-xs font-semibold transition sm:text-sm",
                activeFilter === filter
                  ? "bg-brand text-black"
                  : "bg-bg-soft text-muted hover:bg-line hover:text-ink",
              ].join(" ")}
            >
              {filter}
            </button>
          ))}
        </div>
      </section>

      {error && (
        <div className="flex items-center gap-2 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          <FiAlertCircle className="shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <section className="grid gap-3">
        {loading ? (
          <div className="rounded-lg border border-line bg-white p-5 text-sm text-muted shadow-sm">
            Loading bookings...
          </div>
        ) : safeBookings.length > 0 ? (
          safeBookings.map((booking) => (
            <BookingCard
              key={booking.id}
              booking={booking}
              onAccept={handleAccept}
              onDecline={handleDecline}
              walletBalance={walletBalance}
              onRecharge={() => navigate("/garage/wallet")}
            />
          ))
        ) : (
          <div className="rounded-lg border border-dashed border-line bg-white p-8 text-center text-sm text-muted shadow-sm">
            No bookings found.
          </div>
        )}
      </section>
    </div>
  );
}
