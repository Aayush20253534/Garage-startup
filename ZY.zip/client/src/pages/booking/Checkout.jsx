import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useApp } from "@/hooks/useApp";
import api from "@/api/axios";
import LocationPicker from "@/components/maps/LocationPicker";
import {
  buildFullAddress,
  getDefaultUserLocation,
  getProfileAddress,
  hasUsableIndiaCoordinates,
  parseAddressParts,
} from "@/utils/address";
import {
  formatServicePriceRange,
  formatRupeeRange,
  formatRupees,
  getServiceMinPrice,
  getServiceMaxPrice,
} from "@/utils/priceRange";
import { calculatePlatformFee } from "@/utils/platformFee";
import { payForBooking } from "@/utils/bookingPayment";
import { requireAvailableCityName } from "@/utils/cityAvailability";
import { addRecentActivity } from "@/utils/activityLog";
import {
  FiAlertCircle,
  FiCheckCircle,
  FiCreditCard,
  FiPhone,
  FiTrash2,
  FiTruck,
  FiEdit,
  FiSave,
  FiX,
} from "react-icons/fi";

const getCheckoutAddressForm = ({ location, user }) => {
  const defaultUserLocation = getDefaultUserLocation(user);
  const source = location || defaultUserLocation || {};
  const fullAddress =
    source.formattedAddress ||
    source.fullAddress ||
    source.address ||
    getProfileAddress(user) ||
    "";

  const parts = parseAddressParts(fullAddress);

  return {
    ...source,
    ...parts,
    address: source.address || parts.address,
    city: parts.city || source.city || "",
    formattedAddress: fullAddress,
    fullAddress,
  };
};

const toBoolean = (value) =>
  value === true ||
  value === 1 ||
  value === "1" ||
  String(value).toLowerCase() === "true";

const isCartItemComingSoon = (item) =>
  toBoolean(item?.isComingSoon) ||
  toBoolean(item?.categoryComingSoon) ||
  toBoolean(item?.category?.isComingSoon);

const INDIA_PHONE_REGEX = /^\+91[6-9]\d{9}$/;
const ACTIVE_VEHICLE_BOOKING_STATUSES = [
  "PENDING_PAYMENT",
  "SEARCHING_GARAGE",
  "GARAGE_ASSIGNED",
  "CONFIRMED",
  "IN_PROGRESS",
];

const getVehicleLabel = (vehicle) =>
  `${vehicle?.brand || ""} ${vehicle?.model || ""}`.trim() ||
  vehicle?.registrationNumber ||
  "this vehicle";

const getActiveBookingPath = (booking) =>
  booking?.status === "PENDING_PAYMENT"
    ? "/dashboard/pending-bookings"
    : "/dashboard/bookings";

const getActiveVehicleBookingMessage = (booking, vehicle) => {
  const bookingLabel = booking?.bookingCode || booking?.id || "active booking";

  return `${getVehicleLabel(vehicle)} already has an active booking (${bookingLabel}). Complete or cancel it before booking this vehicle again.`;
};

const normalizeIndianPhone = (value = "") => {
  let digits = String(value).replace(/\D/g, "");

  if (digits.length > 10 && digits.startsWith("91")) {
    digits = digits.slice(2);
  }

  digits = digits.slice(0, 10);
  return digits ? `+91${digits}` : "";
};

export default function Checkout() {
  const {
    cart,
    vehicle,
    location,
    setLocation,
    user,
    setUser,
    clearCart,
    clearBookingCaches,
    clearProfileCache,
    fetchProfile,
  } = useApp();
  const nav = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [savingPhone, setSavingPhone] = useState(false);
  const [phoneDraft, setPhoneDraft] = useState(user?.phone || "");
  const [pendingBooking, setPendingBooking] = useState(null);
  const [activeVehicleBooking, setActiveVehicleBooking] = useState(null);
  const [editingAddress, setEditingAddress] = useState(false);
  const [wallet, setWallet] = useState(null);
  const [useWallet, setUseWallet] = useState(false);
  const [addressForm, setAddressForm] = useState(() =>
    getCheckoutAddressForm({ location, user }),
  );

  const subTotalMin = cart.reduce(
    (sum, item) => sum + getServiceMinPrice(item),
    0,
  );
  const subTotalMax = cart.reduce(
    (sum, item) => sum + getServiceMaxPrice(item),
    0,
  );
  const payAtGarageMin = subTotalMin;
  const payAtGarageMax = subTotalMax;
  const payNowAmount = calculatePlatformFee(payAtGarageMax);
  const walletBalance = Number(wallet?.balance || 0);
  const walletAmountUsed = useWallet
    ? Math.min(walletBalance, payNowAmount)
    : 0;
  const cashfreePayNowAmount = Math.max(payNowAmount - walletAmountUsed, 0);
  const savedPhone = normalizeIndianPhone(user?.phone || "");
  const phoneToSave = normalizeIndianPhone(phoneDraft);
  const hasSavedPhone = INDIA_PHONE_REGEX.test(savedPhone);
  const canSavePhone = INDIA_PHONE_REGEX.test(phoneToSave);
  const comingSoonItems = cart.filter(isCartItemComingSoon);
  const hasComingSoonItems = comingSoonItems.length > 0;
  const blocksCurrentVehicleBooking =
    Boolean(activeVehicleBooking?.id) &&
    activeVehicleBooking.id !== pendingBooking?.id;
  const activeVehicleBookingPath = getActiveBookingPath(activeVehicleBooking);

  useEffect(() => {
    setPhoneDraft(user?.phone || "");
  }, [user?.phone]);

  useEffect(() => {
    let mounted = true;

    api
      .get("/wallet")
      .then((response) => {
        if (mounted) setWallet(response.data?.data || null);
      })
      .catch(() => {
        if (mounted) setWallet(null);
      });

    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (useWallet && walletBalance <= 0) {
      setUseWallet(false);
    }
  }, [useWallet, walletBalance]);

  useEffect(() => {
    let mounted = true;

    if (!vehicle?.id || pendingBooking?.id) {
      setActiveVehicleBooking(null);

      return () => {
        mounted = false;
      };
    }

    api
      .get("/bookings", {
        params: {
          status: ACTIVE_VEHICLE_BOOKING_STATUSES.join(","),
        },
      })
      .then((response) => {
        if (!mounted) return;

        const bookings = response.data?.data || [];
        const matchingBooking = bookings.find(
          (booking) =>
            booking.vehicleId === vehicle.id ||
            booking.vehicle?.id === vehicle.id,
        );

        setActiveVehicleBooking(matchingBooking || null);
      })
      .catch(() => {
        if (mounted) setActiveVehicleBooking(null);
      });

    return () => {
      mounted = false;
    };
  }, [vehicle?.id, pendingBooking?.id]);

  useEffect(() => {
    if (!editingAddress) {
      setAddressForm(getCheckoutAddressForm({ location, user }));
    }
  }, [editingAddress, location, user]);

  const savePhoneNumber = async () => {
    if (!canSavePhone) {
      setError("Enter a valid 10-digit Indian mobile number before payment.");
      return false;
    }

    try {
      setSavingPhone(true);
      setError("");

      const response = await api.patch("/customer/profile", {
        phone: phoneToSave,
      });
      const responseData = response.data?.data;
      const responseUser = responseData?.user || responseData || {};
      const nextUser = {
        ...(user || {}),
        ...responseUser,
        phone: responseUser.phone || phoneToSave,
      };

      setUser?.(nextUser);
      clearProfileCache?.();
      await fetchProfile?.({ force: true });
      return true;
    } catch (err) {
      setError(
        err.response?.data?.message ||
          err.message ||
          "Could not save phone number. Please try again.",
      );
      return false;
    } finally {
      setSavingPhone(false);
    }
  };

  const buildLocationPayload = async () => {
    const defaultUserLocation = getDefaultUserLocation(user);
    const currentAddress =
      location?.fullAddress || buildFullAddress(location) || location?.address;

    if (hasUsableIndiaCoordinates(location) && currentAddress) {
      const city = await requireAvailableCityName(location);

      return {
        latitude: Number(location.latitude),
        longitude: Number(location.longitude),
        address: currentAddress,
        city,
        placeId: location.placeId || null,
      };
    }

    if (
      defaultUserLocation?.address &&
      hasUsableIndiaCoordinates(defaultUserLocation)
    ) {
      const city = await requireAvailableCityName(defaultUserLocation);

      return {
        latitude: Number(defaultUserLocation.latitude),
        longitude: Number(defaultUserLocation.longitude),
        address: defaultUserLocation.formattedAddress || defaultUserLocation.address,
        city,
        placeId: defaultUserLocation.placeId || null,
      };
    }

    return null;
  };

  const saveAddress = async () => {
    let city = "";

    try {
      city = await requireAvailableCityName(addressForm);
    } catch (err) {
      setError(err.message);
      return;
    }

    if (!hasUsableIndiaCoordinates(addressForm)) {
      setError("Search and confirm the exact address on the map.");
      return;
    }

    const canonicalAddressForm = { ...addressForm, city };
    const fullAddress =
      canonicalAddressForm.formattedAddress ||
      canonicalAddressForm.fullAddress ||
      buildFullAddress(canonicalAddressForm);
    const nextLocation = {
      ...canonicalAddressForm,
      city,
      fullAddress,
      formattedAddress: fullAddress,
      address: fullAddress,
      latitude: Number(addressForm.latitude),
      longitude: Number(addressForm.longitude),
    };

    setLocation(nextLocation);

    try {
      await api.post("/locations", {
        latitude: nextLocation.latitude,
        longitude: nextLocation.longitude,
        address: fullAddress,
        formattedAddress: fullAddress,
        city,
        placeId: nextLocation.placeId || null,
        addressComponents: nextLocation.addressComponents || undefined,
        source: nextLocation.source === "GPS" ? "GPS" : "MANUAL",
        isDefault: true,
      });
      clearProfileCache?.();
      await fetchProfile?.({ force: true });
      addRecentActivity({
        type: "LOCATION",
        title: "Changed service location",
        detail: `${city}${canonicalAddressForm.area ? `, ${canonicalAddressForm.area}` : ""}`,
        path: "/checkout",
      });
    } catch (err) {
      console.error("Failed to save address to profile:", err);
    }

    setEditingAddress(false);
    setError("");
  };

  const bookService = async () => {
    if (!vehicle?.id) {
      setError("Please select a vehicle before checkout.");
      nav("/booking/vehicle");
      return;
    }

    if (blocksCurrentVehicleBooking) {
      setError(
        getActiveVehicleBookingMessage(activeVehicleBooking, vehicle),
      );
      return;
    }

    if (cart.length === 0) {
      setError("Please add at least one service before checkout.");
      nav("/booking/services");
      return;
    }

    if (hasComingSoonItems) {
      setError(
        `${comingSoonItems.map((item) => item.name).join(", ")} ${
          comingSoonItems.length === 1 ? "is" : "are"
        } coming soon. Remove ${
          comingSoonItems.length === 1 ? "it" : "them"
        } before checkout.`,
      );
      return;
    }

    if (!hasSavedPhone) {
      setError("Save a valid mobile number before opening payment.");
      return;
    }

    let checkoutLocation = null;

    try {
      checkoutLocation = await buildLocationPayload();
    } catch (err) {
      setError(err.message);
      setEditingAddress(true);
      return;
    }

    if (!checkoutLocation) {
      setError("Please save a valid service location before checkout.");
      setEditingAddress(true);
      return;
    }

    try {
      setLoading(true);
      setError("");

      let booking = pendingBooking;

      if (!booking?.id) {
        const bookingRes = await api.post("/bookings/checkout", {
          vehicleId: vehicle.id,
          serviceIds: cart.map((item) => item.id),
          location: checkoutLocation,
        });

        booking = bookingRes.data.data;
        setPendingBooking(booking);
      }

      const paidBooking = await payForBooking({ booking, useWallet });

      addRecentActivity({
        type: "BOOKING",
        title: "Paid booking fee",
        detail:
          paidBooking?.bookingCode ||
          booking.bookingCode ||
          cart.map((item) => item.name).join(", "),
        path: "/dashboard/bookings",
      });

      clearCart();
      clearBookingCaches?.();
      setPendingBooking(null);
      nav("/tracking", {
        state: {
          bookingId: paidBooking?.id || booking.id,
          bookingCode: paidBooking?.bookingCode || booking.bookingCode,
        },
      });
    } catch (err) {
      setError(
        err.response?.data?.message ||
          err.message ||
          "Could not complete booking payment. Please try again.",
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container-x grid gap-8 py-12 lg:grid-cols-[1fr_400px]">
      <div>
        <h1 className="text-3xl font-bold sm:text-4xl">Checkout</h1>
        <p className="mt-1 text-muted">
          Pay the platform fee now to start garage search. The final service
          amount is paid directly to the garage in cash after the work is
          complete.
        </p>

        {error && (
          <div className="mt-5 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-600">
            {error}
          </div>
        )}

        {blocksCurrentVehicleBooking && (
          <div className="mt-5 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">
            <div className="flex items-start gap-3">
              <FiAlertCircle
                className="mt-0.5 shrink-0 text-lg text-amber-700"
                aria-hidden="true"
              />
              <div>
                <p className="font-semibold">
                  This vehicle already has an active booking.
                </p>
                <p className="mt-1 leading-6 text-amber-800">
                  Complete or cancel{" "}
                  {activeVehicleBooking.bookingCode ||
                    activeVehicleBooking.id ||
                    "that booking"}{" "}
                  before booking {getVehicleLabel(vehicle)} again. You can
                  still book another saved vehicle.
                </p>
                <button
                  type="button"
                  onClick={() => nav(activeVehicleBookingPath)}
                  className="mt-3 inline-flex h-9 items-center justify-center rounded-lg bg-ink px-3 text-xs font-bold text-white transition hover:bg-ink-2"
                >
                  View active booking
                </button>
              </div>
            </div>
          </div>
        )}

        {hasComingSoonItems && (
          <div className="mt-5 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
            <span className="font-semibold">Coming soon:</span>{" "}
            {comingSoonItems.map((item) => item.name).join(", ")}. Remove
            {comingSoonItems.length === 1 ? " this service" : " these services"}{" "}
            before booking.
          </div>
        )}

        {!hasSavedPhone && (
          <div className="card-soft mt-5 grid gap-4 border border-amber-200 bg-amber-50 p-5">
            <div className="flex items-start gap-3">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white text-amber-700">
                <FiPhone />
              </span>
              <div>
                <h3 className="font-semibold text-amber-900">
                  Mobile number required
                </h3>
                <p className="mt-1 text-sm text-amber-800">
                  Save your phone number first. Cashfree needs it to open the
                  payment window.
                </p>
              </div>
            </div>

            <div className="grid gap-3 sm:grid-cols-[1fr_auto]">
              <input
                value={phoneDraft}
                onChange={(event) => {
                  setPhoneDraft(event.target.value.replace(/[^\d+]/g, ""));
                  setError("");
                }}
                inputMode="tel"
                autoComplete="tel"
                placeholder="10-digit mobile number"
                className="h-11 rounded-xl border border-amber-200 bg-white px-4 text-sm outline-none focus:border-amber-500"
              />
              <button
                type="button"
                onClick={savePhoneNumber}
                disabled={savingPhone || !canSavePhone}
                className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-ink px-5 text-sm font-bold text-white shadow-sm transition hover:bg-ink-2 disabled:cursor-not-allowed disabled:opacity-60"
              >
                <FiCheckCircle />
                {savingPhone ? "Saving..." : "Save phone"}
              </button>
            </div>
          </div>
        )}

        <div className="card-soft mt-8 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Delivery Address</h3>
            {!editingAddress && (
              <button
                type="button"
                onClick={() => setEditingAddress(true)}
                className="inline-flex h-9 items-center justify-center gap-1.5 rounded-lg border border-line bg-white px-3 text-sm font-semibold text-ink shadow-sm transition hover:border-ink/25 hover:bg-bg-soft"
              >
                <FiEdit /> Edit
              </button>
            )}
          </div>

          {editingAddress ? (
            <div className="grid gap-4">
              <LocationPicker
                value={addressForm}
                onChange={(next) => {
                  setAddressForm(next);
                  setError("");
                }}
                label="Search delivery address"
                helper="Select the address and confirm the exact service entrance."
                showCurrentLocation
                required
              />

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setEditingAddress(false)}
                  className="inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-xl border border-line bg-white px-4 text-sm font-semibold text-ink shadow-sm transition hover:border-ink/25 hover:bg-bg-soft"
                >
                  <FiX /> Cancel
                </button>
                <button
                  type="button"
                  onClick={saveAddress}
                  className="inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-xl bg-brand px-4 text-sm font-bold text-black shadow-sm shadow-brand/25 transition hover:bg-brand-dark"
                >
                  <FiSave /> Save address
                </button>
              </div>
            </div>
          ) : (
            <div className="text-muted">
              {addressForm.formattedAddress || addressForm.fullAddress || buildFullAddress(addressForm) || "No address set"}
            </div>
          )}
        </div>

        <div className="card-soft mt-6 p-6">
          <h3 className="mb-4 text-lg font-semibold">
            Benefits with this booking
          </h3>
          <ul className="grid gap-3 text-sm sm:grid-cols-2">
            {[
              "Booking Confirmation",
              "Priority Slot",
              "30-Day Warranty",
              "24x7 Customer Support",
            ].map((benefit) => (
              <li key={benefit} className="flex items-center gap-2">
                <FiCheckCircle className="text-brand-dark" /> {benefit}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <aside className="card-soft h-fit p-5 sm:p-6 lg:sticky lg:top-24">
        <div className="flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand">
            <FiTruck />
          </span>
          <div className="text-sm">
            <div className="font-semibold">
              {vehicle?.brand || "Hyundai"} {vehicle?.model || "i20"}
            </div>
            <div className="text-xs text-muted">
              {vehicle?.fuelType || vehicle?.fuel || "Petrol"}
            </div>
          </div>
        </div>

        <hr className="my-4 border-line" />

        <div className="mb-2 flex items-center justify-between gap-3">
          <div className="font-semibold">Order Summary</div>
          {cart.length > 0 && (
            <button
              type="button"
              onClick={clearCart}
              className="inline-flex h-9 items-center justify-center gap-1.5 rounded-lg border border-line bg-white px-3 text-xs font-semibold text-muted shadow-sm transition hover:border-red-200 hover:bg-red-50 hover:text-red-600"
            >
              <FiTrash2 /> Clear
            </button>
          )}
        </div>
        <div className="grid gap-2 text-sm">
          {cart.length === 0 ? (
            <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3 text-muted">
              <span className="min-w-0 truncate">No services selected</span>
              <span className="whitespace-nowrap text-right">
                {formatRupees(0)}
              </span>
            </div>
          ) : (
            cart.map((item) => (
              <div
                key={item.id}
                className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3"
              >
                <span className="min-w-0 truncate">{item.name}</span>
                <span className="whitespace-nowrap text-right font-semibold">
                  {formatServicePriceRange(item)}
                </span>
              </div>
            ))
          )}
        </div>

        <hr className="my-4 border-line" />

        <div className="grid gap-2 text-sm">
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
            <span className="text-muted">Cash at service</span>
            <span className="whitespace-nowrap text-right font-semibold">
              {formatRupeeRange(payAtGarageMin, payAtGarageMax)}
            </span>
          </div>
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
            <span className="text-muted">Platform fee</span>
            <span className="whitespace-nowrap text-right font-semibold">
              {formatRupees(payNowAmount)}
            </span>
          </div>
        </div>

        <label
          className={`mt-4 flex cursor-pointer items-start gap-3 rounded-xl border p-3 text-sm transition ${
            walletBalance > 0
              ? "border-brand/40 bg-brand/10 hover:bg-brand/15"
              : "border-line bg-bg-soft text-muted"
          }`}
        >
          <input
            type="checkbox"
            checked={useWallet}
            disabled={walletBalance <= 0 || payNowAmount <= 0}
            onChange={(event) => setUseWallet(event.target.checked)}
            className="mt-1 h-4 w-4 rounded border-line accent-black disabled:cursor-not-allowed"
          />
          <span className="min-w-0 flex-1">
            <span className="block font-semibold text-ink">
              Use wallet balance
            </span>
            <span className="mt-0.5 block text-xs text-muted">
              Available: {formatRupees(walletBalance)}
              {useWallet && walletAmountUsed > 0
                ? ` • Applying ${formatRupees(walletAmountUsed)}`
                : ""}
            </span>
          </span>
        </label>

        <div className="mt-4 rounded-xl border border-line bg-white p-3 text-sm">
          {useWallet && walletAmountUsed > 0 && (
            <div className="mb-2 grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3 text-muted">
              <span>Wallet applied</span>
              <span className="whitespace-nowrap text-right font-semibold text-green-700">
                -{formatRupees(walletAmountUsed)}
              </span>
            </div>
          )}
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3 text-base">
            <span className="font-semibold">Amount to pay now</span>
            <span className="whitespace-nowrap text-right text-xl font-bold">
              {formatRupees(cashfreePayNowAmount)}
            </span>
          </div>
        </div>

        <button
          type="button"
          onClick={bookService}
          disabled={
            loading ||
            cart.length === 0 ||
            hasComingSoonItems ||
            blocksCurrentVehicleBooking ||
            !hasSavedPhone
          }
          className="mt-5 inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-brand px-4 text-sm font-bold text-black shadow-sm shadow-brand/25 transition hover:bg-brand-dark disabled:cursor-not-allowed disabled:opacity-70"
        >
          <FiCreditCard />{" "}
          {loading
            ? cashfreePayNowAmount > 0
              ? "Opening payment..."
              : "Activating booking..."
            : hasComingSoonItems
              ? "Remove Coming Soon Services"
              : cart.length === 0
                ? "Add services to continue"
                : blocksCurrentVehicleBooking
                  ? "Complete active booking first"
                  : !hasSavedPhone
                    ? "Save phone to pay"
                    : cashfreePayNowAmount > 0
                      ? `Pay ${formatRupees(cashfreePayNowAmount)} Now`
                      : "Pay with wallet"}
        </button>
        <div className="mt-3 text-center text-xs text-muted">
          Pay only the platform fee now. The service amount is paid in cash at
          the garage after work is complete.
        </div>
      </aside>
    </div>
  );
}
